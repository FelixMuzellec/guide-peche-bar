// Configuration du site Plouguerneau (Pays des Abers, Finistère nord) : tout ce qui est propre au lieu
// (spots, zones, ports de marée, principes). Le moteur (src/engine) est commun aux applications.
//
// Recherche du 29/10/2026. Chaque fait porte sa source ; ce qui n'en a pas est marqué « déduit »
// (confidence:"inference"). Aucun spot de la rade de Brest, du goulet ou de Crozon : ils sont déjà
// dans le guide de Logonna-Daoulas.
export const SITE = {
  id: "plouguerneau",
  name: "Plouguerneau",
  region: "Pays des Abers, Finistère nord",
  dept: "29880",
  headerLabel: "PAYS DES ABERS",
  // Coordonnées de la commune (Wikipédia) : requises pour le calcul solaire réel.
  lat: 48.6078, lon: -4.5042,
  tidePort: "L'Aber Wrac'h",
  tideSources: "constantes TICON-4 (Le Conquet, Roscoff) ; ports secondaires ajustés sur les tables publiées par marine.meteoconsult.fr (données SHOM) : L'Aber Wrac'h, Brignogan-Plage, L'Aber Ildut",
  weatherSources: "Open-Meteo (AROME, ECMWF), modèle de vagues Open-Meteo",
  zones: {
    local: { label: "Pays des Abers", anchor: "Plouguerneau / Landéda (29880, 29870)", sea: "open" },
    // L'intérieur de l'Aber Wrac'h : la houle du large n'y entre pas, le clapot naît du vent sur le plan d'eau.
    // fetchKm : ordre de grandeur déduit de la longueur de l'aber, faute de mesure.
    aber:  { label: "Intérieur des abers", anchor: "Paluden (Lannilis / Plouguerneau)", sea: "rade", fetchKm: 2 },
    inter: { label: "Côte des Légendes", anchor: "Kerlouan (29890)", sea: "open" },
    far:   { label: "Iroise nord", anchor: "Lanildut / Plouarzel / Le Conquet (29840, 29217)", sea: "open" },
  },
  // Marnage moyen morte-eau ↔ vive-eau à L'Aber Wrac'h (coefficients 45 et 95) : moyenne 2026 du calcul de marée,
  // cohérente avec les tables d'octobre 2026.
  marnage: { neap: 3.4, spring: 6.8 },
  // Calendrier des proies : repris des guides de la rade de Brest et du Cotentin (mêmes espèces côtières).
  preyCalendar: [
    { name:"Crevette (bouquet, grise)", couche:"sous-surface", months:[1,2,3,4,5,6,7,8,9,10,11,12], weight:2,
      size:"3-7 cm", guidance:"Profil court et discret. Souple 8-10 cm animé lentement sur les bordures de goémon et les fonds mixtes." },
    { name:"Lançon / équille", couche:"sous-surface", months:[4,5,6,7,8,9], weight:5,
      size:"8-15 cm", guidance:"La proie reine de l'été sur les fonds de sable. Profils fins et allongés : souple fin, stickbait élancé." },
    { name:"Crabe (vert, mou en période de mue)", couche:"fond", months:[5,6,7,8,9], weight:3,
      size:"3-6 cm", guidance:"Source peche-poissons.com (2026) : dans les abers, les imitations de crabe « très efficaces sur les bars d'estuaire ». Souple compact animé très lentement au ras du fond." },
    { name:"Alevins de mulet", couche:"surface", months:[6,7,8,9], weight:3,
      size:"3-8 cm", guidance:"Bancs en surface près des bordures et dans les abers. Petit stickbait ou souple weightless passé au bord du banc." },
    { name:"Gobies et blennies", couche:"fond", months:[1,2,3,4,5,6,7,8,9,10,11,12], weight:2,
      size:"5-10 cm", guidance:"Proie de fond permanente des côtes rocheuses. Souple plombé ou texan gratté sur les plaques de sable entre les roches." },
    { name:"Sprat", couche:"mi-eau", months:[10,11,12,1,2,3], weight:4,
      size:"8-12 cm", guidance:"Bancs d'hiver. Shad de 10 cm plombé de 12 à 25 g selon profondeur et courant (peche.com). Suivre les oiseaux." },
  ],
  seedJournal: [],
  // ── Marée : calculée localement ─────────────────────────────────
  // Le Conquet : station harmonique TICON-4. Les autres ports sont ajustés sur les
  // tables d'octobre 2026, puis contrôlés sur novembre 2026 (mois jamais utilisé pour l'ajustement).
  tide: {
    defaultPort: "aberwrach",
    ports: {
      leconquet: { label: "Le Conquet", kind: "harmonic", station: "leconquet", z0: 3.968, lagH: -0.01,
        accuracy: "contrôlée contre les tables SHOM : ±3,3 min · ±3 cm (novembre 2026)" },
      aberwrach: { label: "L'Aber Wrac'h", kind: "secondary", ref: "leconquet", lagH: 0.49,
        hw: { t: [30.3299, 0.29395], h: [4.558, 1.09796] }, lw: { t: [28.3108, 0.21917], h: [4.3047, 1.14574] },
        accuracy: "contrôlée contre les tables SHOM : ±3,0 min · ±4 cm (novembre 2026, mois de contrôle)" },
      brignogan: { label: "Brignogan-Plage", kind: "secondary", ref: "roscoff", lagH: 0.72,
        hw: { t: [-21.3489, -0.11107], h: [5.047, 0.92842] }, lw: { t: [-22.5792, 0.96275], h: [4.9603, 0.94737] },
        accuracy: "contrôlée contre les tables SHOM : ±2,8 min · ±4 cm (novembre 2026, mois de contrôle)" },
      aberildut: { label: "L'Aber Ildut", kind: "secondary", ref: "leconquet", lagH: 0.17,
        hw: { t: [-4.7581, 3.02132], h: [4.2548, 1.09269] }, lw: { t: [-7.1018, 4.50417], h: [4.0998, 1.08729] },
        accuracy: "contrôlée contre les tables SHOM : ±4,5 min · ±4 cm (novembre 2026, mois de contrôle)" },
      // Corsen est entre Le Conquet et l'Aber Ildut : poids d'après la latitude (48,4145 entre 48,3591 et 48,4710).
      corsen: { label: "Corsen (interpolé)", kind: "interp", a: "leconquet", b: "aberildut", w: 0.495,
        accuracy: "Interpolé Le Conquet / L'Aber Ildut, non contrôlé sur place (les deux ports sont à ±3 à ±5 min)" },
    },
  },
  sstTypical: [10, 17],
};

// ═══════════════════════════════════════════════════════════════════
// PRINCIPES DE PÊCHE DU SECTEUR (sourcés)
// ═══════════════════════════════════════════════════════════════════
export const GENERAL_PRINCIPLES = {
  title: "Principes de la pêche du bar du bord au Pays des Abers",
  items: [
    {
      rule: "Les abers : faciles du bord et riches en bars",
      source: "mieuxpecher.com — « Top 10 des coins de pêche en Bretagne (1/2) » (Norbert, 15/04/2018, mis à jour le 21/04/2020)",
      explain: "« Réputés assez faciles à pêcher du bord et pleins de bars. » À basse mer la rivière semble à sec ; à pleine mer « la mer remonte très loin ». Dans l'Aber Wrac'h, « le secteur de Paluden jusqu'au pont du Diable est un secteur à ne pas manquer » ; dans l'Aber Benoît, « le secteur de Brenduff est intéressant à prospecter ».",
    },
    {
      rule: "Estuaire : pêche à vue, imitations de crabe, coefficients 50 à 80",
      source: "peche-poissons.com — Jean-Baptiste Vidal, « Bar en Bretagne… où, quand, comment ? » (19/10/2026)",
      explain: "Les estuaires du Finistère, dont les abers Wrac'h, Benoît et Ildut, sont « riches en crustacés ». La pêche à vue y est l'approche la plus productive pour les gros bars ; les imitations de crabe sont « très efficaces sur les bars d'estuaire ». Coefficients de 50 à 80 de préférence ; les trois premières heures de montante et les trois dernières de descendante sont les meilleures, avec des variations d'un estuaire à l'autre.",
    },
    {
      rule: "Les trois premières heures de montante ou de descendante",
      source: "peche.com / Delalande Pêche (repris du guide de la rade de Brest)",
      explain: "L'activité culmine quand le courant charrie la nourriture ; les étales sont moins productives. Sur la côte des abers, aucune source relue ne donne de règle propre à chaque pointe : le guide s'en sert comme repère, à recaler avec ton journal.",
    },
    {
      rule: "Lire le terrain à basse mer",
      source: "peche-poissons.com — Franck Ripault, pêche du bar en wading dans les abers (Pêche Mouche n° 172, 31/07/2026)",
      explain: "Deux milieux : l'estuaire, « interface entre l'eau douce et l'eau salée », ou la côte ouverte de sable et de roche. Postes cités : cuvettes de sable, rochers isolés cerclés d'algues, hauts-fonds rocheux ; une laisse d'algues échouées signale un courant. La montée de l'eau coupe vite les passages.",
    },
    {
      rule: "Courants dans l'axe des abers, travers au large ; brisants dès 1 m de houle",
      source: "voileaviron.org — topo FVA n° 43, « Les Abers »",
      explain: "Dans les abers, le courant entre et sort à peu près dans l'axe ; dehors, le courant côtier le prend souvent en travers : au Libenter, il peut atteindre 3 nœuds (SHOM). Des brisants se forment sur les roches dès que la houle dépasse 1 m ; les bancs de brume sont fréquents et difficiles à prévoir.",
    },
    {
      rule: "Sécurité en wading",
      source: "peche-poissons.com — Franck Ripault (31/07/2026)",
      explain: "Se renseigner sur les horaires des marées, prévenir quelqu'un de son itinéraire, téléphone dans une poche étanche et sifflet, waders indispensables, attention à la roche glissante et à la mer qui monte.",
    },
  ],
};

// ═══════════════════════════════════════════════════════════════════
// 10 SPOTS — chaque champ marqué par niveau de confiance
//   confidence: "verified" = info sourcée / "inference" = déduction raisonnée
// Distances : estimées (vol d'oiseau depuis le bourg × 1,4, à 50 km/h), détour par Lannilis
// compté quand il faut contourner l'aber. À corriger avec ton expérience.
// ═══════════════════════════════════════════════════════════════════
export const SPOTS = [

  // ══════════════════════════════════════════════════════════
  // 1. PENN ENEZ — GRÈVE BLANCHE (Plouguerneau)
  // ══════════════════════════════════════════════════════════
  {
    id:"pennenez", tidePort:"aberwrach", zone:"local", isLocal:true, dangerLevel:1,
    name:"Penn Enez – Grève Blanche", subtitle:"Koréjou, Plouguerneau",
    distance:"≈ 5 min", distMin:5, coords:"48°37,7'N 4°31,6'W", lat:48.628972, lon:-4.52667,
    type:"POINTE ROCHEUSE + GRÈVE", color:"#22c55e",
    terrain:{
      fond:"Côte basse très découpée : plages de sable blanc, grèves de galets, amas de rochers et dunes (visorando).",
      encombrement:2,
      gratter:"texan",
      prof:{ cls:"peu", why:"Côte basse à rochers et grèves, marnage de 3,4 à 6,8 m : peu d'eau au bord (déduit, aucune sonde)." },
      couches:["surface", "sous-surface", "mi-eau", "fond"],
      montage:"Texan ou tête weedless près des rochers ; tête plombée classique seulement sur les plaques de sable.",
      conseils:["À basse mer, repérer les couloirs de sable entre les roches : le bar y entre avec le flot.", "Les rochers isolés cerclés d'algues sont des postes (Ripault, 2026) : lancer au ras, jamais dedans."],
      confidence:"inference",
      source:"Déduit de la description de la côte (visorando) et du principe de lecture du terrain (Ripault)",
      faits:[
        { t:"Penn Enez : une digue ; le site servait au séchage, au stockage et au brûlage du goémon.", s:"visorando.com — « Terre et mer autour de la chapelle Saint-Michel à Plouguerneau »" },
        { t:"Le port du Koréjou est le plus important de Plouguerneau (plaisance, pêche professionnelle, activités nautiques).", s:"visorando.com — même circuit" },
        { t:"Plouguerneau a 45 km de côte, îles comprises : le plus long littoral communal de France.", s:"Wikipédia (en) — Plouguerneau" },
        { t:"Le phare de l'Île Vierge, haut de 82,5 m, domine la côte.", s:"visorando.com" },
      ],
    },
    coefBand:[30,50,85,105],
    // Aucune source sur le coefficient pour ce poste : plage du guide pour une côte rocheuse ouverte, déduite.
    coefMin:50, coefIdeal:85, coefMax:105, houleMax:1.5,
    // Côte nord du Léon, face à la Manche (Wikipédia : la commune est entre l'Aber Wrac'h et la Manche). Orientation déduite.
    exposedAngles:[315,337.5,0,22.5], shelteredAngles:[135,157.5,180],
    weatherNote:"Côte nord, face à la Manche, au pied de l'Île Vierge. Exposée aux vents de NO à NE ; abritée des vents de sud. Orientation déduite de la carte, à confirmer sur place.",
    sources:[
      "mieuxpecher.com — « Coins de pêche – Finistère NORD » (Norbert, 10/05/2018) : « Penn Enez à Plouguerneau »",
      "visorando.com — « Terre et mer autour de la chapelle Saint-Michel à Plouguerneau » (départ : parking au bout de la Grève Blanche, N 48,628972° / O 4,52667°)",
      "Wikipédia (en) — Plouguerneau",
    ],
    topology:{
      fond:{ text:"Grève de galets ou plage de sable blanc, amas de rochers et dunes, petits ports (visorando).", confidence:"verified" },
      structure:{ text:"Digue de Penn Enez et port du Koréjou ; archipel de Lilia et Île Vierge au large. Chenaux de sable entre les roches, à repérer à basse mer.", confidence:"inference" },
      exposition:{ text:"Côte nord face à la Manche : vents de NO à NE de face, sud de dos. Déduit de la carte.", confidence:"inference" },
      courant:{ text:"Courant de marée côtier, modéré au bord ; au large, le courant traversier peut atteindre 3 nœuds au Libenter (SHOM, cité par Voile-Aviron). Pas de mesure au poste.", confidence:"inference" },
      bars:{ text:"Poste cité parmi les coins de pêche du Finistère nord (mieuxpecher.com). Aucune source sur la taille ou la saison des poissons ici.", confidence:"verified" },
    },
    tidalRules:{
      typeHeure:"3 PREMIÈRES HEURES DE MONTANT",
      montantOuDescendant:"Montant dominant : le flot recouvre la grève et les platiers et remet la nourriture en circulation. Les trois dernières heures du descendant sont le second créneau (principe général, peche.com / Delalande).",
      description:"Côte basse à marnage fort : tout se joue sur le mouvement de l'eau. À basse mer, lire le terrain ; au flot, pêcher les couloirs de sable et les rochers qui se couvrent.",
      windows:[
        { id:"pe1", label:"3 premières heures de montant", phase:"bm", offsetBefore:0.0, offsetAfter:3.0, tidePhaseType:"montant", priority:"prime",
          note:"Le flot entre par les couloirs de sable entre les roches. Souple texan ou weightless au ras des algues." },
        { id:"pe2", label:"Fin de montant et pleine mer", phase:"pm", offsetBefore:-2.0, offsetAfter:0.5, tidePhaseType:"montant", priority:"bon",
          note:"Les rochers sont couverts : leurre de surface au-dessus des têtes de roche si la mer est calme." },
        { id:"pe3", label:"3 dernières heures de descendant", phase:"bm", offsetBefore:-3.0, offsetAfter:0.0, tidePhaseType:"descendant", priority:"bon",
          note:"L'eau se retire des platiers : postes de sortie, au débouché des couloirs." },
      ],
      lifeHack:"Repérer à basse mer les cuvettes de sable et les rochers isolés cerclés d'algues : ce sont les postes du flot (Ripault, 2026).",
    },
    lures:[
      { name:"Souple weightless ou texan 10-12 cm", color:"Naturel / blanc", weight:"sans plomb ou tête 5-7 g", technique:"Au ras des algues sur le flot. Repère d'un guide du cap Sizun : Gambler 5\" sur tête texane 5 g, ou Dolive Shad 4,5\" sans plomb." },
      { name:"Stickbait 110-130 mm", color:"Ghost / sardine", weight:"14-27 g", technique:"Walk-the-dog au-dessus des rochers couverts, mer calme, crépuscule." },
      { name:"Shad 9-10 cm tête plombée", color:"Naturel", weight:"tête 10-15 g", technique:"Sur les plaques de sable seulement. Repère du même guide : Nitro Shad 90 sur tête de 15 g." },
    ],
    access:"Parking au bout de la Grève Blanche, puis sentier côtier (GR34) vers Penn Enez et le Koréjou (visorando).",
    securite:[
      { t:"Marée montante : ne pas se laisser couper le retour sur les platiers et les îlots (marnage de 3,4 à 6,8 m).", s:"peche-poissons.com, F. Ripault (2026) · marnage calculé" },
    ],
  },

  // ══════════════════════════════════════════════════════════
  // 2. POINTE DE ROC'H PELGUENT (Plouguerneau)
  // ══════════════════════════════════════════════════════════
  {
    id:"pelguent", tidePort:"aberwrach", zone:"local", isLocal:true, dangerLevel:1,
    name:"Pointe de Roc'h Pelguent", subtitle:"Plouguerneau, face à l'Île Vierge",
    distance:"≈ 5 min", distMin:6, coords:"48°38,2'N 4°32,3'W", lat:48.636505, lon:-4.538915,
    type:"POINTE ROCHEUSE", color:"#4ade80",
    terrain:{
      fond:"Gros rocher sur une pointe (ancien éperon barré), côte rocheuse et grèves de part et d'autre (visorando).",
      encombrement:3,
      gratter:"non",
      prof:{ cls:"peu", why:"Pointe basse sur une côte à fort marnage : peu d'eau au pied à mi-marée (déduit, aucune sonde)." },
      couches:["surface", "sous-surface"],
      montage:"Weightless, texan ou leurre de surface : une tête plombée nue finit dans la roche.",
      conseils:["Pêcher la pointe quand le courant de marée la longe, pas à l'étale.", "Lancer en éventail : les deux côtés de la pointe ne travaillent pas au même moment."],
      confidence:"inference",
      source:"Déduit de la description du site (visorando)",
      faits:[
        { t:"Roc'h Pelguent : « beau point de vue sur la côte Est dont la belle plage de la Grève Blanche » ; un gros rocher, ancien éperon barré.", s:"visorando.com — « Terre et mer autour de la chapelle Saint-Michel à Plouguerneau »" },
        { t:"Coordonnées de la pointe : 48,636505, -4,538915.", s:"visorando.com — « Pointe de Roc'h Pelguent »" },
        { t:"Vues sur l'Île Wrac'h et l'Île Vierge.", s:"visorando.com — randonnées de la pointe" },
      ],
    },
    coefBand:[30,50,85,105],
    coefMin:50, coefIdeal:85, coefMax:105, houleMax:1.4,
    exposedAngles:[292.5,315,337.5,0], shelteredAngles:[112.5,135,157.5],
    weatherNote:"Pointe de la côte nord, tournée vers le NO et l'Île Vierge. Exposée de l'ouest au nord ; abritée des vents de SE. Orientation déduite de la carte.",
    sources:[
      "mieuxpecher.com — « Coins de pêche – Finistère NORD » : « Roc'h ar Pelguent à Plouguerneau »",
      "visorando.com — « Pointe de Roc'h Pelguent » (coordonnées) et circuit de la chapelle Saint-Michel",
    ],
    topology:{
      fond:{ text:"Roche dominante autour d'un gros rocher (éperon barré), grèves voisines (visorando).", confidence:"verified" },
      structure:{ text:"Pointe avancée entre deux anses : le courant de marée la contourne et crée une veine et un contre-courant.", confidence:"inference" },
      exposition:{ text:"Tournée vers le NO (Île Vierge, Île Wrac'h) : vents d'O à N de face.", confidence:"inference" },
      courant:{ text:"Veine de courant à la pointe au plus fort de la marée ; pas de mesure.", confidence:"inference" },
      bars:{ text:"Poste cité parmi les coins de pêche du Finistère nord (mieuxpecher.com).", confidence:"verified" },
    },
    tidalRules:{
      typeHeure:"MI-MARÉE (COURANT ÉTABLI)",
      montantOuDescendant:"Les deux sens : la pointe travaille quand le courant la longe, aux 3e et 4e heures de la marée (règle des douzièmes).",
      description:"Pointe rocheuse classique : la veine de courant décide du moment. À l'étale, elle s'endort.",
      windows:[
        { id:"rp1", label:"Montant établi (2e à 4e heure)", phase:"bm", offsetBefore:1.5, offsetAfter:4.0, tidePhaseType:"montant", priority:"prime",
          note:"Veine de courant le long de la pointe. Souple weightless ou texan dérivé dans le courant." },
        { id:"rp2", label:"Descendant établi (2e à 4e heure)", phase:"pm", offsetBefore:1.5, offsetAfter:4.0, tidePhaseType:"descendant", priority:"bon",
          note:"Le courant s'inverse : pêcher l'autre côté de la pointe." },
      ],
      lifeHack:"Venir à basse mer une première fois pour voir le pied de la pointe : on y lit les têtes de roche qu'on pêchera couvertes.",
    },
    lures:[
      { name:"Souple weightless 12 cm", color:"Naturel / blanc", weight:"sans plomb", technique:"Dérivé dans la veine de courant, au ras des algues." },
      { name:"Stickbait 110-130 mm", color:"Ghost / sardine", weight:"14-27 g", technique:"Au-dessus des têtes de roche couvertes, mer calme, crépuscule." },
    ],
    access:"Sentier côtier (GR34) depuis le parking de la Grève Blanche (visorando).",
    securite:[
      { t:"Roche glissante couverte d'algues : semelles crantées.", s:"peche-poissons.com, F. Ripault (2026)" },
    ],
  },

  // ══════════════════════════════════════════════════════════
  // 3. ABER WRAC'H — PALUDEN → PONT DU DIABLE
  // ══════════════════════════════════════════════════════════
  {
    id:"paluden", tidePort:"aberwrach", zone:"aber", isLocal:true, dangerLevel:1,
    name:"Aber Wrac'h : Paluden – pont du Diable", subtitle:"Lannilis / Plouguerneau, intérieur de l'aber",
    riviere: "Aber Wrac'h",
    distance:"≈ 5 min", distMin:5, coords:"48°35,3'N 4°31,3'W", lat:48.588233, lon:-4.521446,
    type:"ESTUAIRE", color:"#16a34a",
    terrain:{
      fond:"Rives d'estuaire ; le pont du Diable « n'est en fait qu'un gué à marée basse » (sitytrail). Nature exacte du fond non décrite par les sources.",
      encombrement:2,
      gratter:"texan",
      prof:{ cls:"peu", why:"Intérieur d'aber qui découvre largement à basse mer (mieuxpecher : la rivière « semble à sec ») ; déduit, aucune sonde." },
      couches:["surface", "sous-surface", "fond"],
      montage:"Imitation de crabe ou souple texan au ras du fond ; weightless en bordure.",
      conseils:["Pêche à vue par eau claire : marcher lentement le long des rives et chercher les poissons qui remontent avec le flot (Vidal, 2026).", "Respecter les parcs et les mouillages."],
      confidence:"inference",
      source:"Déduit des sources sur l'aber (mieuxpecher, Vidal, sitytrail, Voile-Aviron)",
      faits:[
        { t:"« Le secteur de Paluden jusqu'au pont du Diable est un secteur à ne pas manquer. »", s:"mieuxpecher.com — Top 10 des coins de pêche en Bretagne (1/2)" },
        { t:"Le pont du Diable est un gué à marée basse ; petit port à Paluden.", s:"sitytrail.com — « Aber Wrac'h de Paluden au pont du Diable »" },
        { t:"L'Aber Wrac'h se remonte jusqu'au pont de Paluden ; dans les abers, le courant entre et sort à peu près dans l'axe.", s:"voileaviron.org — topo FVA n° 43, « Les Abers »" },
      ],
    },
    // Plage de coefficient de la source : 50 à 80 dans les estuaires du Finistère (Vidal, 2026).
    coefBand:[35,50,80,100],
    coefMin:50, coefIdeal:80, coefMax:100, houleMax:2.5,
    exposedAngles:[45,67.5,225,247.5], shelteredAngles:[135,315],
    weatherNote:"Intérieur de l'aber : la houle du large n'y entre pas ; seul le vent qui souffle dans l'axe lève un clapot. Axe déduit de la carte.",
    sources:[
      "mieuxpecher.com — « Top 10 des coins de pêche en Bretagne (1/2) » (Norbert, 2018, mis à jour 2020)",
      "peche-poissons.com — J.-B. Vidal, « Bar en Bretagne… où, quand, comment ? » (19/10/2026) : estuaires des abers, pêche à vue, imitations de crabe, coefficients 50-80",
      "sitytrail.com — « Aber Wrac'h de Paluden au pont du Diable » (départ 48,588233 / -4,521446)",
      "voileaviron.org — topo FVA n° 43, « Les Abers »",
    ],
    topology:{
      fond:{ text:"Rives d'estuaire, gué au pont du Diable à basse mer (sitytrail).", confidence:"verified" },
      structure:{ text:"Aber (ria) : l'eau entre et sort dans l'axe ; le bar remonte avec le flot et redescend avec le jusant.", confidence:"verified" },
      exposition:{ text:"Plan d'eau abrité de la houle ; clapot par vent dans l'axe de l'aber. Axe déduit de la carte.", confidence:"inference" },
      courant:{ text:"Entrant et sortant dans l'axe de l'aber (Voile-Aviron) ; maximal à mi-marée, nul aux étales (règle des douzièmes).", confidence:"verified" },
      bars:{ text:"Secteur « à ne pas manquer » (mieuxpecher). Estuaires « riches en crustacés », gros bars à vue (Vidal).", confidence:"verified" },
    },
    tidalRules:{
      typeHeure:"3 PREMIÈRES HEURES DE MONTANTE · 3 DERNIÈRES DE DESCENDANTE",
      montantOuDescendant:"Règle de la source pour les estuaires : les trois premières heures de montante et les trois dernières de descendante, avec des variations d'un estuaire à l'autre (Vidal, 2026).",
      description:"Estuaire à marée : le bar entre avec le flot sur les rives qui se couvrent, puis ressort avec le jusant.",
      windows:[
        { id:"pl1", label:"3 premières heures de montante", phase:"bm", offsetBefore:0.0, offsetAfter:3.0, tidePhaseType:"montant", priority:"prime",
          note:"Règle de la source. Pêche à vue en bordure, imitation de crabe au ras du fond." },
        { id:"pl2", label:"3 dernières heures de descendante", phase:"bm", offsetBefore:-3.0, offsetAfter:0.0, tidePhaseType:"descendant", priority:"prime",
          note:"Règle de la source. Les poissons ressortent par le chenal : pêcher les sorties de bordures." },
      ],
      lifeHack:"Plus en amont, la marée arrive un peu plus tard qu'à l'entrée de l'aber : l'heure affichée est celle du port de L'Aber Wrac'h (écart non chiffré).",
    },
    lures:[
      { name:"Imitation de crabe", color:"Vert / brun", weight:"texan 5-10 g", technique:"Source : « très efficaces sur les bars d'estuaire » (Vidal, 2026). Posée devant un poisson repéré, animée par petits sauts." },
      { name:"Souple weightless 10-12 cm", color:"Naturel", weight:"sans plomb", technique:"En bordure, sur le flot, lent." },
    ],
    access:"Petit port de Paluden (Lannilis), puis bord de l'aber vers l'est jusqu'au pont du Diable (sitytrail).",
    securite:[
      { t:"Le gué du pont du Diable n'est praticable qu'à marée basse : ne pas s'y engager au flot.", s:"sitytrail.com (gué à marée basse) · prudence du guide" },
    ],
  },

  // ══════════════════════════════════════════════════════════
  // 4. DUNES DE SAINTE-MARGUERITE (Landéda)
  // ══════════════════════════════════════════════════════════
  {
    id:"saintemarguerite", tidePort:"aberwrach", zone:"local", isLocal:false, dangerLevel:2,
    name:"Dunes de Sainte-Marguerite", subtitle:"Presqu'île Sainte-Marguerite, Landéda",
    distance:"≈ 20 min", distMin:20, coords:"48°35,7'N 4°36,1'W", lat:48.5947, lon:-4.6017,
    type:"PLAGE + ROCHERS", color:"#84cc16",
    terrain:{
      fond:"Grandes plages de sable fin et criques ; îlots rocheux (Cézon, Tariec, Roc'h Avel) atteignables à pied à basse mer (Landéda).",
      encombrement:1,
      gratter:"oui",
      prof:{ cls:"estran", why:"Plages de sable fin à fort marnage : estran qui découvre loin (déduit, aucune sonde)." },
      couches:["surface", "sous-surface", "mi-eau", "fond"],
      montage:"Souple sur tête plombée légère sur le sable ; weightless près des îlots.",
      conseils:["Leurres souples : c'est l'approche citée pour ce secteur (mieuxpecher).", "Prospecter le bord des îlots et les sorties de criques au flot."],
      confidence:"inference",
      source:"Déduit de la fiche randonnée de la commune et de mieuxpecher",
      faits:[
        { t:"« Grandes plages de sable fin, criques plus intimistes » ; dunes de 46 ha, espace naturel protégé, « espèces protégées dont il faut prendre le plus grand soin ».", s:"landeda.fr — fiche rando circuit 3, « Balade des dunes » (départ GPS 48,5947 / -4,6017)" },
        { t:"Île Cézon, Enez Vihan et Tariec sont atteignables à pied et propices à la pêche à pied ; fort Vauban sur Cézon (1694).", s:"landeda.fr — même fiche" },
        { t:"Les dunes de Sainte-Marguerite attirent kitesurfeurs, wingsurfeurs et véliplanchistes.", s:"visorando.com — « Entre Beg ar Vilh et Sainte-Marguerite »" },
      ],
    },
    coefBand:[30,45,85,105],
    coefMin:45, coefIdeal:85, coefMax:105, houleMax:1.8,
    // Entre l'embouchure de l'Aber Benoît et celle de l'Aber Wrac'h, face à l'Iroise (visorando) : orientation O-NO déduite.
    exposedAngles:[270,292.5,315], shelteredAngles:[90,112.5,135],
    weatherNote:"Plages tournées vers l'Iroise, entre les deux abers. Exposées d'O à NO ; vent d'est de dos. Orientation déduite.",
    sources:[
      "mieuxpecher.com — « Coins de pêche – Finistère NORD » : « La presqu'île Sainte-Marguerite aux leurres souples »",
      "landeda.fr — fiche rando circuit 3, « Balade des dunes »",
      "visorando.com — « Entre Beg ar Vilh et Sainte-Marguerite » ; « La presqu'île Sainte-Marguerite en longeant l'Aber Wrac'h et l'Aber Benoît »",
    ],
    topology:{
      fond:{ text:"Sable fin, criques, îlots rocheux (Landéda).", confidence:"verified" },
      structure:{ text:"Presqu'île entre deux embouchures d'aber : bancs de sable, îlots et passes que le flot remplit.", confidence:"inference" },
      exposition:{ text:"Face à l'Iroise (O-NO). Déduit de la carte.", confidence:"inference" },
      courant:{ text:"Courant d'embouchure aux deux extrémités ; travers au large (Voile-Aviron). Pas de mesure au poste.", confidence:"inference" },
      bars:{ text:"Secteur cité pour la pêche aux leurres souples (mieuxpecher).", confidence:"verified" },
    },
    tidalRules:{
      typeHeure:"MONTANT",
      montantOuDescendant:"Plage à fort marnage : le flot qui recouvre le sable est le moment de référence (principe général) ; descendant en second, aux sorties des criques.",
      description:"Grande plage claire : chercher les structures (îlots, bancs, criques) plutôt que le large.",
      windows:[
        { id:"sm1", label:"3 premières heures de montant", phase:"bm", offsetBefore:0.0, offsetAfter:3.0, tidePhaseType:"montant", priority:"prime",
          note:"Le flot recouvre le sable et les bords d'îlots. Souple sur tête légère, récupération lente." },
        { id:"sm2", label:"Fin de descendant", phase:"bm", offsetBefore:-2.5, offsetAfter:0.0, tidePhaseType:"descendant", priority:"bon",
          note:"Sorties de criques et de passes entre les îlots." },
      ],
      lifeHack:"Les îlots atteints à pied à basse mer sont aussi des pièges : noter l'heure de la basse mer et repartir tôt.",
    },
    lures:[
      { name:"Souple 10-12 cm tête plombée", color:"Naturel / blanc", weight:"tête 7-15 g", technique:"Approche citée pour la presqu'île (mieuxpecher). Gratté lentement sur le sable." },
      { name:"Long bill minnow ou slug", color:"Ghost / lançon", weight:"10-20 g", technique:"Sur les bancs de sable peu profonds au flot (repère de la côte des havres du Cotentin)." },
    ],
    access:"Route de Sainte-Marguerite (Landéda) ; parking au départ de la « Balade des dunes » (landeda.fr). Rester sur les sentiers : dunes protégées.",
    securite:[
      { t:"Îlots atteignables à pied à basse mer : repartir avant que la mer ne coupe le passage.", s:"landeda.fr (îlots accessibles à pied) · peche-poissons.com, F. Ripault (2026)" },
      { t:"Dunes protégées (46 ha, espèces protégées) : rester sur les sentiers balisés.", s:"landeda.fr" },
    ],
  },

  // ══════════════════════════════════════════════════════════
  // 5. EMBOUCHURE DE L'ABER BENOÎT (Beg ar Vilh, Landéda)
  // ══════════════════════════════════════════════════════════
  {
    id:"aberbenoit", tidePort:"aberwrach", zone:"local", isLocal:false, dangerLevel:2,
    name:"Embouchure de l'Aber Benoît", subtitle:"Beg ar Vilh, Landéda",
    riviere: "Aber Benoît",
    distance:"≈ 20 min", distMin:22, coords:"48°34,5'N 4°35,9'W", lat:48.575815, lon:-4.598854,
    type:"EMBOUCHURE", color:"#a3e635",
    terrain:{
      fond:"Ria large et profonde à l'embouchure ; à basse mer, le lit vaseux et des bancs de sable se découvrent (saint-pabu.bzh).",
      encombrement:2,
      gratter:"texan",
      prof:{ cls:"peu", why:"Embouchure large et profonde au chenal, mais bordures qui découvrent à basse mer (saint-pabu.bzh) ; déduit pour le bord." },
      couches:["surface", "sous-surface", "mi-eau", "fond"],
      montage:"Texan ou tête légère sur les bordures ; plus lourd seulement dans le chenal en plein courant.",
      conseils:["Les bordures de l'embouchure sont le poste cité (cannes-peche).", "Respecter les parcs ostréicoles et mytilicoles de l'aber."],
      confidence:"inference",
      source:"Déduit des descriptions de l'aber (saint-pabu.bzh, Voile-Aviron)",
      faits:[
        { t:"L'Aber Benoît se jette dans la mer à 5 km au sud de l'Aber Wrac'h, entre Saint-Pabu et Landéda ; ria d'environ 8 km, « large et profonde » à l'estuaire ; vasière et bancs de sable découverts à basse mer.", s:"saint-pabu.bzh — « La perle des Abers »" },
        { t:"Huîtres et moules élevées dans l'aber ; port ostréicole de Beg ar Vilh.", s:"saint-pabu.bzh · visorando.com — « Entre Beg ar Vilh et Sainte-Marguerite » (parking avant la jetée : 48,575815 / -4,598854)" },
        { t:"Courant traversier au Libenter jusqu'à 3 nœuds (SHOM) ; brisants sur les roches dès 1 m de houle.", s:"voileaviron.org — topo FVA n° 43" },
      ],
    },
    coefBand:[35,50,80,100],
    coefMin:50, coefIdeal:80, coefMax:100, houleMax:1.5,
    exposedAngles:[292.5,315,337.5], shelteredAngles:[112.5,135,157.5],
    weatherNote:"Embouchure ouverte au NO. Houle d'ouest amortie par les roches du large ; brisants dès 1 m (Voile-Aviron). Orientation déduite de la carte.",
    sources:[
      "mieuxpecher.com — Top 10 Bretagne : « Le secteur de Brenduff est intéressant à prospecter », côte de l'embouchure « intéressante »",
      "cannes-peche.blog4ever.com — « Les coins de pêche à bar / loup (du bord) » (Alain, 07/11/2016) : Landéda, « bordures de l'embouchure de l'Aber Vrac'h et de l'Aber Benoit »",
      "peche-poissons.com — J.-B. Vidal (19/10/2026) : estuaires des abers",
      "saint-pabu.bzh — « La perle des Abers »",
      "voileaviron.org — topo FVA n° 43",
    ],
    topology:{
      fond:{ text:"Embouchure large et profonde, vasière et bancs de sable à basse mer (saint-pabu.bzh).", confidence:"verified" },
      structure:{ text:"Bordures d'embouchure, port de Beg ar Vilh, chenal ; parcs ostréicoles et mytilicoles.", confidence:"verified" },
      exposition:{ text:"Ouverte au NO ; roches au large. Orientation déduite de la carte.", confidence:"inference" },
      courant:{ text:"Dans l'axe de l'aber à l'intérieur, en travers au large (jusqu'à 3 nœuds au Libenter, SHOM via Voile-Aviron).", confidence:"verified" },
      bars:{ text:"Bordures citées pour le bar (cannes-peche) ; estuaires riches en crustacés (Vidal).", confidence:"verified" },
    },
    tidalRules:{
      typeHeure:"3 PREMIÈRES HEURES DE MONTANTE · 3 DERNIÈRES DE DESCENDANTE",
      montantOuDescendant:"Règle des estuaires de la source (Vidal, 2026) ; le courant d'embouchure est maximal à mi-marée.",
      description:"Embouchure : le flot entre sur les bancs, le jusant ressort par le chenal.",
      windows:[
        { id:"ab1", label:"3 premières heures de montante", phase:"bm", offsetBefore:0.0, offsetAfter:3.0, tidePhaseType:"montant", priority:"prime",
          note:"Règle de la source. Bordures qui se couvrent, souple texan." },
        { id:"ab2", label:"3 dernières heures de descendante", phase:"bm", offsetBefore:-3.0, offsetAfter:0.0, tidePhaseType:"descendant", priority:"prime",
          note:"Règle de la source. Sorties de chenal, leurre qui dérive avec le jusant." },
      ],
      lifeHack:"Marée de l'embouchure : l'heure affichée est celle du port de L'Aber Wrac'h, à 5 km (non contrôlé à Beg ar Vilh).",
    },
    lures:[
      { name:"Imitation de crabe", color:"Vert / brun", weight:"texan 5-10 g", technique:"Bars d'estuaire (Vidal, 2026)." },
      { name:"Shad 10 cm tête plombée", color:"Naturel", weight:"tête 10-20 g", technique:"Dans la veine du chenal au plus fort du courant." },
      { name:"Stickbait 110-130 mm", color:"Ghost", weight:"14-27 g", technique:"Au crépuscule sur les bordures, mer calme." },
    ],
    access:"Parking avant la jetée de Beg ar Vilh (visorando), puis GR34 vers l'embouchure.",
    securite:[
      { t:"Vasières et bancs découverts à basse mer : la mer remonte vite sur les bancs.", s:"saint-pabu.bzh · prudence du guide" },
    ],
  },

  // ══════════════════════════════════════════════════════════
  // 6. KERLOUAN — ENEZ AMANN AR ROUZ / MENEHAM
  // ══════════════════════════════════════════════════════════
  {
    id:"kerlouan", tidePort:"brignogan", zone:"inter", isLocal:false, dangerLevel:2,
    name:"Kerlouan : Enez Amann ar Rouz", subtitle:"Meneham, Côte des Légendes",
    distance:"≈ 15 min", distMin:15, coords:"48°39,4'N 4°26,2'W", lat:48.657472, lon:-4.436653,
    type:"CHAOS ROCHEUX", color:"#f59e0b",
    terrain:{
      fond:"Gros rochers granitiques (l'« île aux Vaches » leur doit son nom), côte rocheuse de la Côte des Légendes.",
      encombrement:3,
      gratter:"non",
      prof:{ cls:"peu", why:"Chaos rocheux d'estran sur une côte à fort marnage (déduit, aucune sonde)." },
      couches:["surface", "sous-surface"],
      montage:"Weightless, texan ou surface : pas de tête plombée nue dans le chaos.",
      conseils:["Pêcher les passes entre les blocs quand le flot s'y engouffre.", "Par mer formée, l'écume au pied des blocs tient souvent du poisson (peche.com, principe des roches émergentes) ; ne s'en approcher que si c'est sûr."],
      confidence:"inference",
      source:"Déduit de la description du site (komoot) et des principes peche.com",
      faits:[
        { t:"Enez Amann ar Rouz, « l'île aux Vaches », doit son surnom à ses gros rochers ; propriété privée ouverte au public (avis d'utilisateur).", s:"komoot.com — highlight « Enez Amann Ar Rouz » (48,657472 / -4,436653)" },
        { t:"Le village de Meneham est niché dans les rochers de la Côte des Légendes, à 100 m du GR34.", s:"toutcommenceenfinistere.com — « Site de Meneham »" },
      ],
    },
    coefBand:[30,50,85,105],
    coefMin:50, coefIdeal:85, coefMax:105, houleMax:1.5,
    exposedAngles:[315,337.5,0,22.5], shelteredAngles:[135,157.5,180],
    weatherNote:"Côte nord, face à la Manche. Exposée de NO à NE. Orientation déduite de la carte.",
    sources:[
      "mieuxpecher.com — « Coins de pêche – Finistère NORD » : « Enez Amann ar rouz à Kerlouan »",
      "komoot.com — « Enez Amann Ar Rouz (Île aux Vaches) »",
      "toutcommenceenfinistere.com — « Site de Meneham »",
    ],
    topology:{
      fond:{ text:"Gros rochers granitiques (komoot).", confidence:"verified" },
      structure:{ text:"Chaos de blocs et passes entre les rochers, grèves voisines.", confidence:"inference" },
      exposition:{ text:"Côte nord face à la Manche. Déduit de la carte.", confidence:"inference" },
      courant:{ text:"Courant côtier de la Manche ; pas de mesure au poste.", confidence:"inference" },
      bars:{ text:"Poste cité parmi les coins de pêche du Finistère nord (mieuxpecher).", confidence:"verified" },
    },
    tidalRules:{
      typeHeure:"MONTANT",
      montantOuDescendant:"Montant : les passes entre les blocs se remplissent et le bar y entre (principe général) ; fin de descendant en second.",
      description:"Chaos rocheux : peu de lancers longs, beaucoup de lancers précis.",
      windows:[
        { id:"ke1", label:"Montant (BM+1 → PM−1)", phase:"bm", offsetBefore:1.0, offsetAfter:4.5, tidePhaseType:"montant", priority:"prime",
          note:"Passes entre les blocs qui se remplissent. Weightless au ras des algues." },
        { id:"ke2", label:"Fin de descendant", phase:"bm", offsetBefore:-2.5, offsetAfter:0.0, tidePhaseType:"descendant", priority:"bon",
          note:"Sorties des passes." },
      ],
      lifeHack:"Repérer les passes à basse mer : elles ne se voient plus une fois couvertes.",
    },
    lures:[
      { name:"Souple weightless 12 cm", color:"Naturel / blanc", weight:"sans plomb", technique:"Dans les passes, lent, au ras des algues." },
      { name:"Stickbait 110-130 mm", color:"Ghost / sardine", weight:"14-27 g", technique:"Au-dessus des blocs couverts, mer calme." },
    ],
    access:"Site de Meneham (Kerlouan), à 100 m du GR34 ; l'île est atteignable par la côte.",
    securite:[
      { t:"Chaos de blocs glissants : jamais par mer forte, semelles crantées.", s:"prudence du guide" },
    ],
  },

  // ══════════════════════════════════════════════════════════
  // 7. EMBOUCHURE DE L'ABER ILDUT (Lanildut)
  // ══════════════════════════════════════════════════════════
  {
    id:"aberildut", tidePort:"aberildut", zone:"far", isLocal:false, dangerLevel:2,
    name:"Embouchure de l'Aber Ildut", subtitle:"Lanildut, plage du Crapaud",
    riviere: "Aber Ildut",
    distance:"≈ 40 min", distMin:40, coords:"48°28,3'N 4°45,4'W", lat:48.471001, lon:-4.757318,
    type:"EMBOUCHURE + ROCHES", color:"#f97316",
    terrain:{
      fond:"Embouchure ouverte sur le Chenal du Four, port en eau profonde ; roches à l'entrée (rocher du Crapaud).",
      encombrement:2,
      gratter:"texan",
      prof:{ cls:"peu", why:"Bordures d'embouchure qui découvrent ; chenal profond au port (mieuxpecher) : déduit pour le bord." },
      couches:["surface", "sous-surface", "mi-eau", "fond"],
      montage:"Texan sur les bordures ; tête plombée dans le chenal quand le courant porte.",
      conseils:["Bordures de l'aber et roches face à l'île de Melon : postes cités (cannes-peche).", "Le trafic des goémoniers au port : se tenir à l'écart des quais en activité."],
      confidence:"inference",
      source:"Déduit des descriptions (mieuxpecher, cannes-peche, visorando)",
      faits:[
        { t:"L'Aber Ildut s'ouvre sur le Chenal du Four ; port en eau profonde de Lanildut ; rocher du Crapaud à l'entrée.", s:"mieuxpecher.com — Top 10 des coins de pêche en Bretagne (1/2)" },
        { t:"Lanildut, « premier port européen pour le déchargement d'algues ».", s:"visorando.com — « Nord de Lanildut entre terre, aber et mer » (parking « Vers les Îles », 48,471001 / -4,757318)" },
        { t:"Postes cités : « bordures de l'Aber Ildut, roches face à l'Île de Melon ».", s:"cannes-peche.blog4ever.com (Alain, 07/11/2016)" },
      ],
    },
    coefBand:[35,50,80,100],
    coefMin:50, coefIdeal:80, coefMax:100, houleMax:1.6,
    exposedAngles:[247.5,270,292.5], shelteredAngles:[67.5,90,112.5],
    weatherNote:"Embouchure tournée vers l'ouest et le Chenal du Four. Exposée aux vents d'O ; vent d'est de dos. Orientation déduite de la carte.",
    sources:[
      "mieuxpecher.com — « Coins de pêche – Finistère NORD » : « L'embouchure de l'Aber Idult » ; Top 10 Bretagne",
      "cannes-peche.blog4ever.com — Plouarzel : « Île Ségal, bordures de l'Aber Ildut, roches face à l'Île de Melon »",
      "peche-poissons.com — J.-B. Vidal (19/10/2026) : estuaires des abers",
      "visorando.com — « Nord de Lanildut entre terre, aber et mer »",
    ],
    topology:{
      fond:{ text:"Embouchure sur le Chenal du Four, port en eau profonde, rocher du Crapaud (mieuxpecher).", confidence:"verified" },
      structure:{ text:"Bordures d'aber, roches de l'entrée, île de Melon au large.", confidence:"verified" },
      exposition:{ text:"Tournée vers l'ouest. Déduit de la carte.", confidence:"inference" },
      courant:{ text:"Courant d'embouchure dans l'axe ; courants du Chenal du Four au large (Voile-Aviron les signale, sans chiffre ici).", confidence:"inference" },
      bars:{ text:"Embouchure et bordures citées par deux sources (mieuxpecher, cannes-peche).", confidence:"verified" },
    },
    tidalRules:{
      typeHeure:"3 PREMIÈRES HEURES DE MONTANTE · 3 DERNIÈRES DE DESCENDANTE",
      montantOuDescendant:"Règle des estuaires de la source (Vidal, 2026).",
      description:"Embouchure profonde : le chenal travaille au plus fort du courant, les bordures au flot.",
      windows:[
        { id:"ai1", label:"3 premières heures de montante", phase:"bm", offsetBefore:0.0, offsetAfter:3.0, tidePhaseType:"montant", priority:"prime",
          note:"Règle de la source. Bordures et roches de l'entrée." },
        { id:"ai2", label:"3 dernières heures de descendante", phase:"bm", offsetBefore:-3.0, offsetAfter:0.0, tidePhaseType:"descendant", priority:"prime",
          note:"Règle de la source. Sortie du chenal." },
      ],
      lifeHack:"L'heure de marée vient du port de L'Aber Ildut (table SHOM ajustée, ±4,5 min).",
    },
    lures:[
      { name:"Imitation de crabe", color:"Vert / brun", weight:"texan 5-10 g", technique:"Bordures, bars d'estuaire (Vidal, 2026)." },
      { name:"Shad 10 cm tête plombée", color:"Naturel / blanc", weight:"tête 12-20 g", technique:"Chenal au plus fort du courant." },
      { name:"Stickbait 110-130 mm", color:"Ghost / sardine", weight:"14-27 g", technique:"Roches de l'entrée, crépuscule, mer calme." },
    ],
    access:"Parking « Vers les Îles » près de la plage du Crapaud, à la sortie de Lanildut vers Porspoder (visorando).",
    securite:[
      { t:"Port de goémoniers en activité : ne pas pêcher sur les quais où l'on décharge.", s:"visorando.com (port de déchargement d'algues) · prudence du guide" },
    ],
  },

  // ══════════════════════════════════════════════════════════
  // 8. POINTE DE CORSEN (Plouarzel)
  // ══════════════════════════════════════════════════════════
  {
    id:"corsen", tidePort:"corsen", zone:"far", isLocal:false, dangerLevel:3,
    name:"Pointe de Corsen", subtitle:"Plouarzel, mer d'Iroise",
    distance:"≈ 50 min", distMin:50, coords:"48°24,9'N 4°47,7'W", lat:48.4145, lon:-4.7955,
    type:"POINTE ROCHEUSE / FALAISE", color:"#ef4444",
    terrain:{
      fond:"Pointe escarpée à falaises (Wikipédia) ; roches au pied. Nature du fond au large non décrite par les sources.",
      encombrement:3,
      gratter:"non",
      prof:{ cls:"tombant", why:"Pointe à falaise qui plonge sur l'Iroise : eau plus profonde au pied (déduit, aucune sonde)." },
      couches:["surface", "sous-surface", "mi-eau"],
      montage:"Leurre de surface, stickbait coulant ou souple plombé tenu au-dessus des roches.",
      conseils:["Poste engagé : ne descendre que par mer calme et houle faible."],
      confidence:"inference",
      source:"Déduit de la description de la pointe (Wikipédia)",
      faits:[
        { t:"« A steep and cliffy headland » : point le plus occidental de la France continentale ; site du CROSS Corsen.", s:"Wikipédia (en) — Pointe de Corsen (48°24′52″N 4°47′44″W)" },
        { t:"Île Ségal (Plouarzel) citée parmi les postes à bar du bord.", s:"cannes-peche.blog4ever.com (Alain, 07/11/2016)" },
      ],
    },
    coefBand:[30,50,85,105],
    coefMin:50, coefIdeal:85, coefMax:105, houleMax:1.5,
    exposedAngles:[225,247.5,270,292.5,315], shelteredAngles:[67.5,90,112.5],
    weatherNote:"Pointe la plus à l'ouest de la France continentale, face à l'Iroise : exposée de SO à NO ; seul un vent d'est l'abrite.",
    sources:[
      "mieuxpecher.com — « Coins de pêche – Finistère NORD » : « Pointe de Corsen à Plouarzel »",
      "cannes-peche.blog4ever.com — Plouarzel : « Île Ségal, bordures de l'Aber Ildut, roches face à l'Île de Melon »",
      "Wikipédia (en) — Pointe de Corsen",
    ],
    topology:{
      fond:{ text:"Pointe escarpée à falaises (Wikipédia).", confidence:"verified" },
      structure:{ text:"Pointe avancée sur l'Iroise, îlots au large (Ségal).", confidence:"inference" },
      exposition:{ text:"Plein ouest, houle d'Atlantique directe.", confidence:"inference" },
      courant:{ text:"Courants de l'Iroise et du Chenal du Four au large ; heure non estimée (côte ouverte).", confidence:"inference" },
      bars:{ text:"Poste cité parmi les coins de pêche du Finistère nord (mieuxpecher).", confidence:"verified" },
    },
    tidalRules:{
      typeHeure:"MI-MARÉE + CRÉPUSCULES",
      montantOuDescendant:"Pointe océanique : courant établi et lumière faible comme déclencheurs (principe général). Aucune source propre au poste.",
      description:"Pointe exposée : la houle décide d'abord si l'on peut y aller.",
      windows:[
        { id:"co1", label:"Montant établi", phase:"bm", offsetBefore:1.5, offsetAfter:4.0, tidePhaseType:"montant", priority:"prime",
          note:"Courant établi le long de la pointe. Stickbait ou souple plombé dans la dérive." },
        { id:"co2", label:"Descendant établi", phase:"pm", offsetBefore:1.5, offsetAfter:4.0, tidePhaseType:"descendant", priority:"bon",
          note:"Même approche, de l'autre côté de la pointe." },
      ],
      lifeHack:"Vérifier la houle avant de partir : au-delà de 1,5 m, la pointe n'est pas proposée.",
    },
    lures:[
      { name:"Stickbait 130-150 mm", color:"Ghost / sardine", weight:"25-32 g", technique:"Pour lancer loin face au vent ; plus gros par mer formée." },
      { name:"Souple 12 cm tête plombée", color:"Blanc / naturel", weight:"tête 15-21 g", technique:"Repère d'un guide du cap Sizun : Sand Eel sur tête de 21 g." },
    ],
    access:"Route de la pointe de Corsen (Plouarzel), sentier côtier vers la pointe ; descente aux rochers engagée.",
    securite:[
      { t:"Pointe à falaises exposée à la houle d'Atlantique : jamais seul, gilet, mer calme seulement.", s:"Wikipédia (falaises) · prudence du guide" },
    ],
  },

  // ══════════════════════════════════════════════════════════
  // 9. PLAGE DES BLANCS-SABLONS (Le Conquet)
  // ══════════════════════════════════════════════════════════
  {
    id:"blancssablons", tidePort:"leconquet", zone:"far", isLocal:false, dangerLevel:1,
    name:"Plage des Blancs-Sablons", subtitle:"Le Conquet, au nord de la presqu'île de Kermorvan",
    distance:"≈ 55 min", distMin:55, coords:"48°22,1'N 4°45,8'W", lat:48.3690944, lon:-4.7640023,
    type:"PLAGE EXPOSÉE", color:"#a3e635",
    terrain:{
      fond:"Plage de sable fin d'environ 2,5 km, tournée vers le nord-ouest (office de tourisme Iroise Bretagne).",
      encombrement:1,
      gratter:"oui",
      prof:{ cls:"peu", why:"Grande plage de sable : peu d'eau au bord (déduit, aucune sonde)." },
      couches:["surface", "sous-surface", "mi-eau", "fond"],
      montage:"Souple sur tête plombée ou slug sur le sable ; surface par mer calme.",
      conseils:["La plage est surtout réputée pour le surfcasting : au leurre, prospecter en marchant, l'écume des premières vagues et les bords rocheux aux deux extrémités (déduit).", "Vives et raies signalées sur la plage : regarder où l'on marche."],
      confidence:"inference",
      source:"Déduit des descriptions de la plage (office de tourisme, fishipedia) et des listes de pêcheurs",
      faits:[
        { t:"« Pour le surf casting, cette plage n'est plus à présenter. »", s:"atout-pecheur.fr — Plage des Blancs Sablons (fiche datée 01/02/2014)" },
        { t:"Plage des Blancs-Sablons citée parmi les coins de pêche du Finistère nord, et parmi les spots de pêche au leurre de Le Conquet.", s:"mieuxpecher.com (Norbert, 2018) · guillaume29.over-blog.com (Jegou, 15/05/2005)" },
        { t:"Environ 2,5 km de sable fin, « facing north-west » ; partie ouest surveillée du 1er juillet au 31 août ; site du Conservatoire du littoral, Natura 2000.", s:"iroise-bretagne.bzh — Plage des Blancs Sablons" },
        { t:"Marée importante, zone de vagues ; vives (grande et petite), raie pastenague et raie bouclée possibles ; coordonnées 48,3690944 / -4,7640023.", s:"fishipedia.fr — Plage des Blancs Sablons" },
      ],
    },
    coefBand:[30,45,85,105],
    coefMin:45, coefIdeal:85, coefMax:105, houleMax:1.8,
    // Plage tournée vers le nord-ouest (office de tourisme) : houle et vent de NO de face, vent de SE de dos.
    exposedAngles:[292.5,315,337.5], shelteredAngles:[112.5,135,157.5],
    weatherNote:"Plage tournée vers le nord-ouest (office de tourisme Iroise Bretagne) : la houle et le vent de NO arrivent de face, le vent de SE est de dos.",
    sources:[
      "mieuxpecher.com — « Coins de pêche – Finistère NORD » : « Plage des Blancs-Sablons au Conquet »",
      "atout-pecheur.fr — Plage des Blancs Sablons (surfcasting)",
      "guillaume29.over-blog.com — « spot de pêche au leurre 29 » (Jegou, 2005)",
      "iroise-bretagne.bzh — Plage des Blancs Sablons",
      "fishipedia.fr — Plage des Blancs Sablons (coordonnées, faune)",
    ],
    topology:{
      fond:{ text:"Sable fin sur environ 2,5 km (office de tourisme).", confidence:"verified" },
      structure:{ text:"Grande plage fermée au sud par la presqu'île de Kermorvan (office de tourisme : vue sur la presqu'île et le fort de l'Îlette).", confidence:"verified" },
      exposition:{ text:"Tournée vers le nord-ouest (office de tourisme).", confidence:"verified" },
      courant:{ text:"Courants de plage par houle ; pas de mesure.", confidence:"inference" },
      bars:{ text:"Citée par les pêcheurs (mieuxpecher, liste de spots au leurre de 2005) ; réputée surtout au surfcasting (atout-pecheur).", confidence:"verified" },
    },
    tidalRules:{
      typeHeure:"FLOT + CRÉPUSCULES",
      montantOuDescendant:"Aucune source propre à la plage : flot et lumière faible, comme sur les autres plages du guide.",
      description:"Grande plage de sable : le flot ramène le poisson dans l'écume.",
      windows:[
        { id:"bs1", label:"Montant (BM+1 → PM)", phase:"bm", offsetBefore:1.0, offsetAfter:5.5, tidePhaseType:"montant", priority:"prime",
          note:"Souple sur tête de 10-15 g dans l'écume, en marchant." },
        { id:"bs2", label:"Début de descendant", phase:"pm", offsetBefore:0.0, offsetAfter:2.0, tidePhaseType:"descendant", priority:"bon",
          note:"Bords rocheux des extrémités." },
      ],
      lifeHack:"Le marégraphe du Conquet est à moins de 2 km : l'heure de marée est celle de la plage.",
    },
    lures:[
      { name:"Souple 12 cm tête plombée", color:"Blanc / naturel", weight:"tête 10-21 g", technique:"Dans l'écume des premières vagues." },
      { name:"Stickbait 110-130 mm", color:"Ghost / sardine", weight:"14-27 g", technique:"Mer calme, aube ou crépuscule." },
    ],
    access:"Le Conquet, route de la presqu'île de Kermorvan vers la plage (D28 vers les Blancs-Sablons, patrimoine-iroise.fr).",
    securite:[
      { t:"Vives et raies possibles sur le sable : regarder où l'on pose les pieds, surtout hors de la foule.", s:"fishipedia.fr — Plage des Blancs Sablons" },
    ],
  },

  // ══════════════════════════════════════════════════════════
  // 10. POINTE DE KERMORVAN (Le Conquet)
  // ══════════════════════════════════════════════════════════
  {
    id:"kermorvan", tidePort:"leconquet", zone:"far", isLocal:false, dangerLevel:3,
    name:"Pointe de Kermorvan", subtitle:"Le Conquet, entrée du chenal du Four",
    distance:"≈ 1 h", distMin:58, coords:"48°21,7'N 4°47,4'W", lat:48.3617, lon:-4.79,
    type:"POINTE / PHARE + COURANT", color:"#f87171",
    terrain:{
      fond:"Pointe rocheuse ; le phare est bâti sur une roche à l'extrémité de la presqu'île, relié par une passerelle ; « Les écueils sont apparents » (patrimoine-iroise.fr). Nature du fond au large non décrite.",
      encombrement:3,
      gratter:"non",
      prof:{ cls:"peu", why:"Roches et écueils au pied de la pointe : profondeur non décrite (déduit, aucune sonde)." },
      couches:["surface", "sous-surface", "mi-eau"],
      montage:"Stickbait ou souple plombé tenu au-dessus des écueils ; pas de pêche au fond.",
      conseils:["Pêcher la veine du courant le long de la pointe, depuis un poste haut.", "Jamais sur la passerelle du phare par mer formée."],
      confidence:"inference",
      source:"Déduit de la description de la pointe (patrimoine-iroise.fr, visorando) et des listes de pêcheurs",
      faits:[
        { t:"« Les écueils sont apparents et la violence du courant est évidente. » Le chenal du Four s'ouvre au nord de la presqu'île : « un courant puissant qui s'inverse avec la marée » et « des centaines d'écueils ».", s:"patrimoine-iroise.fr — Le phare de Kermorvan au Conquet" },
        { t:"Passerelle vers le phare : « Il faut imaginer les paquets de mer qui s'écrasent sur ce pont les jours de tempête. »", s:"patrimoine-iroise.fr — Le phare de Kermorvan" },
        { t:"Pointe de Kermorvan citée parmi les coins de pêche du Finistère nord, et parmi les spots de pêche au leurre du Conquet.", s:"mieuxpecher.com (Norbert, 2018) · guillaume29.over-blog.com (Jegou, 15/05/2005)" },
        { t:"Phare carré de 20 m à l'extrémité de la presqu'île, qui marque l'entrée du port du Conquet ; l'Îlette n'est accessible qu'à marée basse.", s:"visorando.com — « Tour de la presqu'île de Kermorvan »" },
        { t:"Phare de Kermorvan : 48°21'42\" N, 4°47'24\" W.", s:"lhdigest.com — Kermorvan Light" },
      ],
    },
    coefBand:[30,45,80,100],
    coefMin:45, coefIdeal:80, coefMax:100, houleMax:1.5,
    exposedAngles:[225,247.5,270,292.5,315], shelteredAngles:[67.5,90,112.5],
    weatherNote:"Extrémité de presqu'île face à l'Iroise et au chenal du Four : exposée d'ouest ; seul un vent d'est l'abrite. Orientation déduite de la carte.",
    sources:[
      "mieuxpecher.com — « Coins de pêche – Finistère NORD » : « Pointe de Kermorvan »",
      "guillaume29.over-blog.com — « spot de pêche au leurre 29 » (Jegou, 2005)",
      "patrimoine-iroise.fr — Le phare de Kermorvan au Conquet (courant, écueils, accès)",
      "visorando.com — Tour de la presqu'île de Kermorvan",
      "lhdigest.com — Kermorvan Light (coordonnées)",
    ],
    topology:{
      fond:{ text:"Roche, écueils apparents (patrimoine-iroise).", confidence:"verified" },
      structure:{ text:"Extrémité de presqu'île, phare sur une roche reliée par une passerelle (patrimoine-iroise).", confidence:"verified" },
      exposition:{ text:"Face à l'ouest et au chenal du Four. Déduit de la carte.", confidence:"inference" },
      courant:{ text:"Courant « puissant qui s'inverse avec la marée » dans le chenal du Four, « violence du courant » à la pointe (patrimoine-iroise). Heure non chiffrée par la source.", confidence:"verified" },
      bars:{ text:"Pointe citée par les pêcheurs (mieuxpecher, liste de spots au leurre de 2005).", confidence:"verified" },
    },
    tidalRules:{
      typeHeure:"COURANT ÉTABLI (MI-MARÉE) + CRÉPUSCULES",
      montantOuDescendant:"Aucune source ne donne l'heure du courant à la pointe : le guide vise le courant établi, entre les renverses, et la lumière faible.",
      description:"Pointe de courant : la houle et le courant décident d'abord si l'on peut y aller.",
      windows:[
        { id:"km1", label:"Montant établi", phase:"bm", offsetBefore:1.5, offsetAfter:4.0, tidePhaseType:"montant", priority:"prime",
          note:"Veine de courant le long de la pointe. Stickbait ou souple plombé dans la dérive." },
        { id:"km2", label:"Descendant établi", phase:"pm", offsetBefore:1.5, offsetAfter:4.0, tidePhaseType:"descendant", priority:"bon",
          note:"Même approche quand le courant s'est inversé." },
      ],
      lifeHack:"Au-delà de 1,5 m de houle, la pointe n'est pas proposée : la passerelle et les roches basses prennent les paquets de mer.",
    },
    lures:[
      { name:"Stickbait 130-150 mm", color:"Ghost / sardine", weight:"25-32 g", technique:"Pour lancer loin et tenir dans le courant." },
      { name:"Souple 12 cm tête plombée", color:"Blanc / naturel", weight:"tête 15-21 g", technique:"Dans la veine de courant, au-dessus des écueils." },
    ],
    access:"Parking en bout de route, puis environ 1 km à pied par une route goudronnée fermée d'une barrière et le chemin côtier jusqu'au phare (patrimoine-iroise.fr) ; départ possible du Conquet par la passerelle sur la ria (visorando).",
    securite:[
      { t:"« La violence du courant est évidente » : poste engagé, jamais seul, gilet, mer calme seulement.", s:"patrimoine-iroise.fr" },
      { t:"Passerelle du phare battue par les « paquets de mer » les jours de tempête : ne pas y pêcher par mer formée.", s:"patrimoine-iroise.fr" },
      { t:"L'Îlette n'est accessible qu'à marée basse : vérifier l'horaire de la marée avant d'y aller.", s:"visorando.com" },
    ],
  },
];
