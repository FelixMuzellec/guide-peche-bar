// Liste des guides et des fichiers du site, partagée par la construction et les tests.
export const SITES = [
  { key: "logonna", config: "src/sites/logonna.config.js", id: "logonna-daoulas", title: "Bar · Logonna-Daoulas", short: "Bar Logonna" },
  { key: "pirou", config: "src/sites/pirou.config.js", id: "pirou-plage", title: "Bar · Pirou Plage", short: "Bar Pirou" },
  { key: "plouguerneau", config: "src/sites/plouguerneau.config.js", id: "plouguerneau", title: "Bar · Plouguerneau", short: "Bar Plouguerneau" },
  { key: "audierne", config: "src/sites/audierne.config.js", id: "audierne", title: "Bar · Audierne", short: "Bar Audierne" },
  { key: "carantec", config: "src/sites/carantec.config.js", id: "carantec", title: "Bar · Carantec", short: "Bar Carantec" },
];
export const SITE_FILES = ["index.html", ...SITES.map((s) => `${s.key}.html`), "manifest.json", "icon-192.png", "icon-512.png", "icon-maskable.png",
  ...SITES.map((s) => `${s.key}.png`), "sw.js"];
