// Dessine les icônes de l'application à partir de assets/app-icon.svg (à relancer
// seulement si l'icône change ; les PNG produits sont versionnés dans assets/).
//   icon-192.png, icon-512.png   coins arrondis, fond transparent (« any »)
//   icon-maskable.png            fond plein, motif dans la zone sûre (Android, iPhone)
// Usage : node scripts/icons.mjs
import { chromium } from "playwright";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const svg = fs.readFileSync(path.join(root, "assets/app-icon.svg"), "utf8");
const motif = svg.match(/<g id="motif">[\s\S]*?<\/g>/)[0];
const BG = "#0b1220";
// « any » : carte arrondie ; « maskable » : carré plein, motif réduit à 78 % autour du
// centre pour rester dans le cercle de 80 % que les lanceurs Android ne rognent jamais.
const any = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect x="16" y="16" width="480" height="480" rx="96" fill="${BG}"/><g transform="translate(0 -22)">${motif}</g></svg>`;
const mask = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" fill="${BG}"/><g transform="translate(256 256) scale(0.78) translate(-256 -278)">${motif}</g></svg>`;

const browser = await chromium.launch();
for (const [name, src, size] of [["icon-192.png", any, 192], ["icon-512.png", any, 512], ["icon-maskable.png", mask, 512]]) {
  const page = await browser.newPage({ viewport: { width: size, height: size } });
  await page.setContent(`<html><body style="margin:0;background:transparent">${src.replace("<svg ", `<svg width="${size}" height="${size}" `)}</body></html>`);
  await page.screenshot({ path: path.join(root, "assets", name), omitBackground: true });
  await page.close();
  console.log(name, size);
}
await browser.close();
