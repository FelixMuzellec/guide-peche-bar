// Construit le site statique à la RACINE du dépôt : GitHub Pages publie la
// branche main, dossier racine (Settings → Pages → Branch main, / (root)).
// C'est le seul réglage qui reste juste quand les fichiers sont déposés depuis
// le téléphone (« Add file → Upload files » ne crée pas de dossier).
//
//   index.html                       accueil (point d'entrée de l'application installée)
//   logonna.html, pirou.html,
//   plouguerneau.html, audierne.html, carantec.html : les cinq guides (JavaScript intégré)
//   manifest.json                    UNE application installable : accueil + cinq guides
//   icon-192.png, icon-512.png, icon-maskable.png, logonna.png, pirou.png, plouguerneau.png, audierne.png, carantec.png
//   sw.js                            fonctionnement hors ligne
//
// Usage : node scripts/build.mjs
import { build } from "esbuild";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
export const OUT = root;
// Feuille de style de Leaflet (carte des spots), intégrée à la page : rien à télécharger.
const LEAFLET_CSS = fs.readFileSync(path.join(root, "node_modules/leaflet/dist/leaflet.css"), "utf8")
  .replace(/\/\*[\s\S]*?\*\//g, "").replace(/\s*\n\s*/g, "").replace(/\s{2,}/g, " ");
const MAP_CSS = ".leaflet-container{font:12px system-ui,sans-serif}.leaflet-tooltip.spot-tip{background:#0b1626;color:#e2e8f0;border:1px solid #334155;"
  + "box-shadow:none;font-weight:600;padding:2px 6px}.leaflet-tooltip.spot-tip::before{display:none}.leaflet-control-attribution{font-size:11.5px}";
// ── Politique de sécurité du contenu (CSP) ─────────────────────────────
// Le seul script autorisé est celui de la page, identifié par son empreinte SHA-256 : un
// script injecté (faille XSS) ne s'exécute pas. Les connexions sont limitées aux services
// dont l'application a besoin. But : protéger la clé API Anthropic et le jeton GitHub
// gardés sur le téléphone. GitHub Pages n'envoie pas d'en-tête CSP : elle est en balise meta
// (frame-ancestors n'y est pas pris en compte).
export const CONNECT = ["https://api.open-meteo.com", "https://marine-api.open-meteo.com", "https://historical-forecast-api.open-meteo.com",
  "https://api.github.com", "https://api.anthropic.com"];
const sha = (txt) => `'sha256-${crypto.createHash("sha256").update(txt, "utf8").digest("base64")}'`;
export function cspFor(script, { connect = [], img = [] } = {}) {
  return [
    "default-src 'none'", `script-src ${sha(script)}`, "style-src 'self' 'unsafe-inline'",
    `img-src 'self' data: blob: ${img.join(" ")}`.trim(), `connect-src 'self' ${connect.join(" ")}`.trim(),
    "manifest-src 'self'", "worker-src 'self'", "base-uri 'none'", "form-action 'none'", "object-src 'none'",
  ].join("; ");
}
const scriptOf = (html) => { const m = html.match(/<script>([\s\S]*?)<\/script>/g) || []; if (m.length !== 1) throw new Error(`CSP : ${m.length} scripts en ligne, 1 attendu`); return m[0].slice(8, -9); };
const withCsp = (html, policy) => html.replace('<meta charset="utf-8">', `<meta charset="utf-8">\n<meta http-equiv="Content-Security-Policy" content="${policy}">`);

import { SITES, SITE_FILES } from "./sites.mjs";
export { SITE_FILES };
const VERSION = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8")).version.replace(/\.0$/, "");
// Nom de l'application installée (écran d'accueil du téléphone).
const APP = { name: "Guides de pêche du bar", short: "Pêche bar" };

const stamp = crypto.createHash("sha256");
for (const s of SITES) {
  // Un seul moteur (src/engine/, src/ui/) ; seule la configuration du site change.
  const engine = path.join(root, "src/ui/App.jsx"), config = path.join(root, s.config);
  const r = await build({
    entryPoints: [path.join(root, "src/main.jsx")],
    // esbuild ≥ 0.25 (correctif de sécurité GHSA-67mh-4wv8-2f99) refuse de cibler Safari 13 et 14 :
    // il juge leur déstructuration défaillante. Cible minimale : Safari 15 (iOS 15, 2021).
    bundle: true, minify: true, format: "iife", target: ["es2019", "safari15"], write: false,
    jsx: "automatic", loader: { ".js": "jsx" },
    define: { __SITE_ID__: JSON.stringify(s.id), "process.env.NODE_ENV": '"production"' },
    plugins: [{ name: "site", setup(b) {
      b.onResolve({ filter: /^APP$/ }, () => ({ path: engine }));
      b.onResolve({ filter: /^SITE_CONFIG$/ }, () => ({ path: config }));
    } }],
    legalComments: "none", logLevel: "warning",
  });
  // Script intégré dans la page : neutralise les séquences qui fermeraient la balise.
  const js = r.outputFiles[0].text.replace(/<\/(script)/gi, "<\\/$1").replace(/<!--/g, "<\\!--");
  stamp.update(js);
  const page = `<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>${s.title}</title>
<meta name="description" content="Guide de pêche du bar aux leurres — marée calculée, météo Open-Meteo par spot.">
<meta name="theme-color" content="#020617">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="${APP.short}">
<link rel="manifest" href="manifest.json">
<link rel="icon" type="image/png" href="${s.key}.png">
<link rel="apple-touch-icon" href="icon-maskable.png">
<style>/* Socle CSS identique à celui des artefacts claude.ai (préflight Tailwind), pour lequel l'interface a été dessinée */
*,::before,::after{box-sizing:border-box;border:0 solid #1e293b}html{line-height:1.5;-webkit-text-size-adjust:100%}
h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}
button,input,optgroup,select,textarea{font-family:inherit;font-size:100%;font-weight:inherit;line-height:inherit;color:inherit;margin:0;padding:0}
button,select{text-transform:none}button,[type=button]{-webkit-appearance:button;background-color:transparent;background-image:none}button{cursor:pointer}
blockquote,dl,dd,h1,h2,h3,h4,h5,h6,hr,figure,p,pre{margin:0}ol,ul{list-style:none;margin:0;padding:0}img,svg,video,canvas{display:block;vertical-align:middle}
html,body{margin:0;background:#020617;color:#e2e8f0}#boot{font:13px system-ui,sans-serif;color:#64748b;padding:40px 16px;text-align:center}@media (pointer:coarse){input,select,textarea{font-size:16px!important}}
:focus-visible{outline:2px solid #38bdf8;outline-offset:2px}@media (prefers-reduced-motion:reduce){*{scroll-behavior:auto!important;animation:none!important}}
${LEAFLET_CSS}${MAP_CSS}</style>
</head>
<body>
<div id="root"><div id="boot">Chargement du guide…</div></div>
<noscript><p style="padding:16px">Cette application nécessite JavaScript.</p></noscript>
<script>
${js}
</script>
</body>
</html>
`;
  fs.writeFileSync(path.join(OUT, `${s.key}.html`), withCsp(page, cspFor(scriptOf(page), { connect: CONNECT, img: ["https://tile.openstreetmap.org"] })));
  fs.copyFileSync(path.join(root, `assets/${s.key}-512.png`), path.join(OUT, `${s.key}.png`));
  console.log(`${s.key}.html : ${(fs.statSync(path.join(OUT, `${s.key}.html`)).size / 1024).toFixed(0)} Ko`);
}
// Une seule application installable pour l'accueil et les cinq guides : toutes les pages
// pointent vers ce manifeste. L'installer depuis n'importe laquelle donne la même
// application, qui s'ouvre sur l'accueil ; appui long sur l'icône (Android) : accès
// direct à un guide.
// Pas de champ « id » : il se résout contre l'ORIGINE (felixmuzellec.github.io, partagée par
// tous les sites GitHub Pages du compte), alors que start_url se résout contre le dossier du
// site. Sans « id », l'identifiant de l'application est start_url : …/guide-peche-bar/.
const manifest = JSON.stringify({
  name: APP.name, short_name: APP.short, lang: "fr", dir: "ltr",
  description: "Pêche du bar aux leurres : Logonna-Daoulas (rade de Brest), Pirou Plage (Cotentin), Plouguerneau (Pays des Abers) et Audierne (Cap Sizun).",
  start_url: "./", scope: "./", display: "standalone", background_color: "#020617", theme_color: "#020617",
  icons: [
    { src: "icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
    { src: "icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
    { src: "icon-maskable.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
  ],
  shortcuts: SITES.map((s) => ({ name: s.title.replace("Bar · ", ""), url: `./${s.key}.html`, icons: [{ src: `${s.key}.png`, sizes: "512x512", type: "image/png" }] })),
}, null, 2) + "\n";
stamp.update(manifest);
fs.writeFileSync(path.join(OUT, "manifest.json"), manifest);
for (const f of ["icon-192.png", "icon-512.png", "icon-maskable.png"]) { stamp.update(fs.readFileSync(path.join(root, "assets", f))); fs.copyFileSync(path.join(root, "assets", f), path.join(OUT, f)); }
// v8.0–v8.3 avaient un manifeste par guide (deux applications séparées) : remplacés.
for (const f of ["logonna-manifest.json", "pirou-manifest.json"]) fs.rmSync(path.join(OUT, f), { force: true });
const home = fs.readFileSync(path.join(root, "src/index.html"), "utf8");
stamp.update(home);
const buildId = stamp.digest("hex").slice(0, 12);
// Le modèle s'appelle sw.template.js : déposé par erreur à la racine, il ne peut
// plus écraser le sw.js construit (c'est arrivé le 11/10/2026).
const shell = ["./", ...SITE_FILES.filter((f) => f !== "sw.js").map((f) => `./${f}`)];
const sw = fs.readFileSync(path.join(root, "src/sw.template.js"), "utf8").replace("__BUILD__", buildId).replace('"__SHELL__"', JSON.stringify(shell).slice(1, -1));
if (sw.includes("__BUILD__") || sw.includes("__SHELL__")) throw new Error("sw.js : identifiant de version ou liste de fichiers non remplacé");
fs.writeFileSync(path.join(OUT, "sw.js"), sw);
const homeOut = home.replace("__VERSION__", `${VERSION} · ${buildId}`);
if (homeOut.includes("__VERSION__") || homeOut === home) throw new Error("index.html : numéro de version non remplacé");
fs.writeFileSync(path.join(OUT, "index.html"), withCsp(homeOut, cspFor(scriptOf(homeOut))));
// GitHub Pages sert les fichiers tels quels (pas de traitement Jekyll).
fs.writeFileSync(path.join(OUT, ".nojekyll"), "");
// Ancienne sortie (v7–v8 : docs/) supprimée pour qu'il n'en reste qu'une version.
fs.rmSync(path.join(root, "docs"), { recursive: true, force: true });
console.log("build", buildId);
