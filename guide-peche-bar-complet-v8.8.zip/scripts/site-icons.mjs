// Dessine l'icône d'un guide (poisson et vagues de assets/app-icon.svg + lettres du site).
// À relancer seulement pour un nouveau guide ; les PNG produits sont versionnés dans assets/.
// Usage : node scripts/site-icons.mjs plouguerneau PG audierne AU
import { chromium } from "playwright";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const svg = fs.readFileSync(path.join(root, "assets/app-icon.svg"), "utf8");
const motif = svg.match(/<g id="motif">[\s\S]*?<\/g>/)[0];
const BG = "#0b1220";
const args = process.argv.slice(2);
if (!args.length || args.length % 2) throw new Error("Usage : node scripts/site-icons.mjs <clé> <lettres> [<clé> <lettres>…]");
const browser = await chromium.launch();
for (let i = 0; i < args.length; i += 2) {
  const [key, letters] = [args[i], args[i + 1]];
  const fs1 = letters.length > 1 ? 74 : 96;
  const icon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect x="16" y="16" width="480" height="480" rx="96" fill="${BG}"/>`
    + `${motif}<text x="440" y="122" text-anchor="end" font-family="DejaVu Sans, Arial, sans-serif" font-weight="700" font-size="${fs1}" fill="#f59e0b">${letters}</text></svg>`;
  for (const size of [192, 512]) {
    const page = await browser.newPage({ viewport: { width: size, height: size } });
    await page.setContent(`<html><body style="margin:0;background:transparent">${icon.replace("<svg ", `<svg width="${size}" height="${size}" `)}</body></html>`);
    await page.screenshot({ path: path.join(root, "assets", `${key}-${size}.png`), omitBackground: true });
    await page.close();
    console.log(`${key}-${size}.png`);
  }
}
await browser.close();
